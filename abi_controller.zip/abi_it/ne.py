import functions as f
#import imps
import abi_funs
import os
#import parse_funs as funs
#for i in range(int(f.reader('num.py')),14):
#    imps.get_funs(i)
#    f.pen(i+1,'num.py')
#    exit()

k = 0
fi = f.list_files('functions_fold/')
print(fi)
f.copy_it('functions_fold/'+fi[k],os.getcwd(),'abi_funs.py')
def do(k,add):
    try:
        import try_em
        print(try_em)
        f.pen(f.reader_C(f.create_path(os.getcwd(),'abi_funs.py')),f.create_path('functions_fold/new_funcs/',str(add)+'.py'))
        print(str(add)+'.py')
        return True
    except:
        return False
varis = f.js_it(f.reader_C('variables/varis.json'))
name_ls,add_js = varis['name_ls'],varis['add_js']
i = 0
while True:
    varis = f.js_it(f.reader_C('variables/varis.json'))
    name_ls,add_js = varis['name_ls'],varis['add_js']
    for i in range(0,len(name_ls)):
        old = f.check_sum(add_js[name_ls[i]])
        print(old)
        f.pen(f.reader_C('functions_fold/'+fi[k]).replace(old,f.check_sum(add_js[name_ls[k]])),'abi_funs.py')
        f.pen('import abi_funs\nabi_funs.add = '+str(f.check_sum(add_js[name_ls[k]]))+'\ntry:\n\tabi_funs.view_all()\nexcept:\n\tprint("no_good")\n','try_em.py')
        print(f.check_sum(add_js[name_ls[k]]),fi[k])
        if do(k,f.check_sum(add_js[name_ls[k]])) == True:
            k = k + 1
            f.copy_it('functions_fold/'+fi[k],os.getcwd(),'abi_funs.py')
            
            old = abi_funs.add
        
    
#for i in range(int(f.reader('num.py')),14):
#    imps.get_funs(i)
#    f.pen(i+1,'num.py')
#    exit()
