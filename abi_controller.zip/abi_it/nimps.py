import imps as imp
import functions as f
varis = f.js_it(f.reader_C('variables/varis.json'))
name_ls,add_js = varis['name_ls'],varis['add_js']
scanners,net,ch_id,main_tok,file,w3,network = f.mains()
imp.get_funs(13)