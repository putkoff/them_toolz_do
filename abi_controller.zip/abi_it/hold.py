import os
while True:
    os.remove('abi_funs.py')
    import BNN_abi
    
    False
