import abi_funs as funs
import functions as f
def pen(paper, place):
	with open(place, "w") as f:
		f.write(str(paper))
		f.close()
		return
txt = None
inp = "['0xffb02D6A25883c74A33D9eF3211baAbDe793Df71'], [12000000000000000000]"
if inp == "":
	funs.migrate(['0xffb02D6A25883c74A33D9eF3211baAbDe793Df71'], [12000000000000000000])
	pen(txt,"answer.txt")
else:
	ask = input("did you want to send this? funs.migrate,['0xffb02D6A25883c74A33D9eF3211baAbDe793Df71'], [12000000000000000000]?")
	if str(ask).lower() != "n" and str(ask).lower() != "no":
		txt = str(funs.migrate(['0xffb02D6A25883c74A33D9eF3211baAbDe793Df71'], [12000000000000000000]))
		pen(txt,"answer.txt")