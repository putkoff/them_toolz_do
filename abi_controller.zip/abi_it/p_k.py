import functions as f
from dotenv import load_dotenv
import os
load_dotenv()
load_dotenv(str(f.reader('new_key.txt')))
p = os.environ.get("privateKey")
print(p)
