from web3 import Web3
import p_k as key
import json
import functions as f
def allowance(address_owner,address_spender):
	x = cont.functions.allowance(address_owner,address_spender).call()
	f.pen(x,"ask.txt")
	print("allowance"," is ",x)
	return x
def approve(address_spender,uint256_amount):
	return cont.functions.approve(address_spender,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def balanceOf(address_account):
	x = cont.functions.balanceOf(address_account).call()
	f.pen(x,"ask.txt")
	print("balanceOf"," is ",x)
	return x
def blacklistAddress(address_account,bool_value):
	return cont.functions.blacklistAddress(address_account,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_account,uint256_amount):
	return cont.functions.burn(address_account,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAll():
	return cont.functions.cashoutAll().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutFee():
	x = cont.functions.cashoutFee().call()
	f.pen(x,"ask.txt")
	print("cashoutFee"," is ",x)
	return x
def cashoutReward(uint256_blocktime):
	return cont.functions.cashoutReward(uint256_blocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNodeRewards(uint256_blocktime):
	return cont.functions.compoundNodeRewards(uint256_blocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNodeWithTokens(string_name,uint256_amount):
	return cont.functions.createNodeWithTokens(string_name,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def decreaseAllowance(address_spender,uint256_subtractedValue):
	return cont.functions.decreaseAllowance(address_spender,uint256_subtractedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def increaseAllowance(address_spender,uint256_addedValue):
	return cont.functions.increaseAllowance(address_spender,uint256_addedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def isTradingEnabled():
	x = cont.functions.isTradingEnabled().call()
	f.pen(x,"ask.txt")
	print("isTradingEnabled"," is ",x)
	return x
def joePair():
	x = cont.functions.joePair().call()
	f.pen(x,"ask.txt")
	print("joePair"," is ",x)
	return x
def joeRouterAddress():
	x = cont.functions.joeRouterAddress().call()
	f.pen(x,"ask.txt")
	print("joeRouterAddress"," is ",x)
	return x
def liquidityPoolFee():
	x = cont.functions.liquidityPoolFee().call()
	f.pen(x,"ask.txt")
	print("liquidityPoolFee"," is ",x)
	return x
def migrate(addressls_addresses_,uint256ls_balances):
	return cont.functions.migrate(addressls_addresses_,uint256ls_balances).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def payee(uint256_index):
	x = cont.functions.payee(uint256_index).call()
	f.pen(x,"ask.txt")
	print("payee"," is ",x)
	return x
def release(address_account):
	return cont.functions.release(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def release(address_token,address_account):
	return cont.functions.release(address_token,address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def released(address_token,address_account):
	x = cont.functions.released(address_token,address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def released(address_account):
	x = cont.functions.released(address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardsFee():
	x = cont.functions.rewardsFee().call()
	f.pen(x,"ask.txt")
	print("rewardsFee"," is ",x)
	return x
def rewardsPool():
	x = cont.functions.rewardsPool().call()
	f.pen(x,"ask.txt")
	print("rewardsPool"," is ",x)
	return x
def setAutomatedMarketMakerPair(address_pair,bool_value):
	return cont.functions.setAutomatedMarketMakerPair(address_pair,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def shares(address_account):
	x = cont.functions.shares(address_account).call()
	f.pen(x,"ask.txt")
	print("shares"," is ",x)
	return x
def swapLiquifyEnabled():
	x = cont.functions.swapLiquifyEnabled().call()
	f.pen(x,"ask.txt")
	print("swapLiquifyEnabled"," is ",x)
	return x
def swapTokensAmount():
	x = cont.functions.swapTokensAmount().call()
	f.pen(x,"ask.txt")
	print("swapTokensAmount"," is ",x)
	return x
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def teamPool():
	x = cont.functions.teamPool().call()
	f.pen(x,"ask.txt")
	print("teamPool"," is ",x)
	return x
def teamPoolFee():
	x = cont.functions.teamPoolFee().call()
	f.pen(x,"ask.txt")
	print("teamPoolFee"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalFees():
	x = cont.functions.totalFees().call()
	f.pen(x,"ask.txt")
	print("totalFees"," is ",x)
	return x
def totalReleased(address_token):
	x = cont.functions.totalReleased(address_token).call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalReleased():
	x = cont.functions.totalReleased().call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalShares():
	x = cont.functions.totalShares().call()
	f.pen(x,"ask.txt")
	print("totalShares"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_recipient,uint256_amount):
	return cont.functions.transfer(address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFrom(address_sender,address_recipient,uint256_amount):
	return cont.functions.transferFrom(address_sender,address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateCashoutFee(uint256_newVal):
	return cont.functions.updateCashoutFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateIsTradingEnabled(bool_newVal):
	return cont.functions.updateIsTradingEnabled(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateLiquidityFee(uint256_newVal):
	return cont.functions.updateLiquidityFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsFee(uint256_newVal):
	return cont.functions.updateRewardsFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsPool(address_newVal):
	return cont.functions.updateRewardsPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRwSwapFee(uint256_newVal):
	return cont.functions.updateRwSwapFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapLiquify(bool_newVal):
	return cont.functions.updateSwapLiquify(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapTokensAmount(uint256_newVal):
	return cont.functions.updateSwapTokensAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamFee(uint256_newVal):
	return cont.functions.updateTeamFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamPool(address_newVal):
	return cont.functions.updateTeamPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def allowance(address_owner,address_spender):
	x = cont.functions.allowance(address_owner,address_spender).call()
	f.pen(x,"ask.txt")
	print("allowance"," is ",x)
	return x
def approve(address_spender,uint256_amount):
	return cont.functions.approve(address_spender,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def balanceOf(address_account):
	x = cont.functions.balanceOf(address_account).call()
	f.pen(x,"ask.txt")
	print("balanceOf"," is ",x)
	return x
def blacklistAddress(address_account,bool_value):
	return cont.functions.blacklistAddress(address_account,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_account,uint256_amount):
	return cont.functions.burn(address_account,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAll():
	return cont.functions.cashoutAll().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutFee():
	x = cont.functions.cashoutFee().call()
	f.pen(x,"ask.txt")
	print("cashoutFee"," is ",x)
	return x
def cashoutReward(uint256_blocktime):
	return cont.functions.cashoutReward(uint256_blocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNodeRewards(uint256_blocktime):
	return cont.functions.compoundNodeRewards(uint256_blocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNodeWithTokens(string_name,uint256_amount):
	return cont.functions.createNodeWithTokens(string_name,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def decreaseAllowance(address_spender,uint256_subtractedValue):
	return cont.functions.decreaseAllowance(address_spender,uint256_subtractedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def increaseAllowance(address_spender,uint256_addedValue):
	return cont.functions.increaseAllowance(address_spender,uint256_addedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def isTradingEnabled():
	x = cont.functions.isTradingEnabled().call()
	f.pen(x,"ask.txt")
	print("isTradingEnabled"," is ",x)
	return x
def joePair():
	x = cont.functions.joePair().call()
	f.pen(x,"ask.txt")
	print("joePair"," is ",x)
	return x
def joeRouterAddress():
	x = cont.functions.joeRouterAddress().call()
	f.pen(x,"ask.txt")
	print("joeRouterAddress"," is ",x)
	return x
def liquidityPoolFee():
	x = cont.functions.liquidityPoolFee().call()
	f.pen(x,"ask.txt")
	print("liquidityPoolFee"," is ",x)
	return x
def migrate(addressls_addresses_,uint256ls_balances):
	return cont.functions.migrate(addressls_addresses_,uint256ls_balances).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def payee(uint256_index):
	x = cont.functions.payee(uint256_index).call()
	f.pen(x,"ask.txt")
	print("payee"," is ",x)
	return x
def release(address_account):
	return cont.functions.release(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def release(address_token,address_account):
	return cont.functions.release(address_token,address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def released(address_token,address_account):
	x = cont.functions.released(address_token,address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def released(address_account):
	x = cont.functions.released(address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardsFee():
	x = cont.functions.rewardsFee().call()
	f.pen(x,"ask.txt")
	print("rewardsFee"," is ",x)
	return x
def rewardsPool():
	x = cont.functions.rewardsPool().call()
	f.pen(x,"ask.txt")
	print("rewardsPool"," is ",x)
	return x
def setAutomatedMarketMakerPair(address_pair,bool_value):
	return cont.functions.setAutomatedMarketMakerPair(address_pair,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def shares(address_account):
	x = cont.functions.shares(address_account).call()
	f.pen(x,"ask.txt")
	print("shares"," is ",x)
	return x
def swapLiquifyEnabled():
	x = cont.functions.swapLiquifyEnabled().call()
	f.pen(x,"ask.txt")
	print("swapLiquifyEnabled"," is ",x)
	return x
def swapTokensAmount():
	x = cont.functions.swapTokensAmount().call()
	f.pen(x,"ask.txt")
	print("swapTokensAmount"," is ",x)
	return x
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def teamPool():
	x = cont.functions.teamPool().call()
	f.pen(x,"ask.txt")
	print("teamPool"," is ",x)
	return x
def teamPoolFee():
	x = cont.functions.teamPoolFee().call()
	f.pen(x,"ask.txt")
	print("teamPoolFee"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalFees():
	x = cont.functions.totalFees().call()
	f.pen(x,"ask.txt")
	print("totalFees"," is ",x)
	return x
def totalReleased(address_token):
	x = cont.functions.totalReleased(address_token).call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalReleased():
	x = cont.functions.totalReleased().call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalShares():
	x = cont.functions.totalShares().call()
	f.pen(x,"ask.txt")
	print("totalShares"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_recipient,uint256_amount):
	return cont.functions.transfer(address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFrom(address_sender,address_recipient,uint256_amount):
	return cont.functions.transferFrom(address_sender,address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateCashoutFee(uint256_newVal):
	return cont.functions.updateCashoutFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateIsTradingEnabled(bool_newVal):
	return cont.functions.updateIsTradingEnabled(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateLiquidityFee(uint256_newVal):
	return cont.functions.updateLiquidityFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsFee(uint256_newVal):
	return cont.functions.updateRewardsFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsPool(address_newVal):
	return cont.functions.updateRewardsPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRwSwapFee(uint256_newVal):
	return cont.functions.updateRwSwapFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapLiquify(bool_newVal):
	return cont.functions.updateSwapLiquify(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapTokensAmount(uint256_newVal):
	return cont.functions.updateSwapTokensAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamFee(uint256_newVal):
	return cont.functions.updateTeamFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamPool(address_newVal):
	return cont.functions.updateTeamPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def disperseTokenSimple(address_token,addressls_recipients,uint256ls_values):
	return cont.functions.disperseTokenSimple(address_token,addressls_recipients,uint256ls_values).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def disperseToken(address_token,addressls_recipients,uint256ls_values):
	return cont.functions.disperseToken(address_token,addressls_recipients,uint256ls_values).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def disperseEther(addressls_recipients,uint256ls_values):
	return cont.functions.disperseEther(addressls_recipients,uint256ls_values).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(uint256_index):
	return cont.functions.burn(uint256_index).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAllNodesRewards(address_account):
	return cont.functions.cashoutAllNodesRewards(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutNodeReward(address_account,uint256__creationTime):
	return cont.functions.cashoutNodeReward(address_account,uint256__creationTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount):
	return cont.functions.compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNode(address_account,string_nodeName,uint256_amount):
	return cont.functions.createNode(address_account,string_nodeName,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getAllNodes(address_account):
	x = cont.functions.getAllNodes(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodes"," is ",x)
	return x
def getAllNodesRewards(address_account):
	x = cont.functions.getAllNodesRewards(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesRewards"," is ",x)
	return x
def getIndexOfKey(address_account):
	x = cont.functions.getIndexOfKey(address_account).call()
	f.pen(x,"ask.txt")
	print("getIndexOfKey"," is ",x)
	return x
def getMinPrice():
	x = cont.functions.getMinPrice().call()
	f.pen(x,"ask.txt")
	print("getMinPrice"," is ",x)
	return x
def getNodeNumberOf(address_account):
	x = cont.functions.getNodeNumberOf(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodeNumberOf"," is ",x)
	return x
def getNodeReward(address_account,uint256__creationTime):
	x = cont.functions.getNodeReward(address_account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("getNodeReward"," is ",x)
	return x
def getNodesCreationTime(address_account):
	x = cont.functions.getNodesCreationTime(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesCreationTime"," is ",x)
	return x
def getNodesLastClaimTime(address_account):
	x = cont.functions.getNodesLastClaimTime(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesLastClaimTime"," is ",x)
	return x
def getNodesNames(address_account):
	x = cont.functions.getNodesNames(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesNames"," is ",x)
	return x
def isNodeOwner(address_account):
	x = cont.functions.isNodeOwner(address_account).call()
	f.pen(x,"ask.txt")
	print("isNodeOwner"," is ",x)
	return x
def minPrice():
	x = cont.functions.minPrice().call()
	f.pen(x,"ask.txt")
	print("minPrice"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardPerNode():
	x = cont.functions.rewardPerNode().call()
	f.pen(x,"ask.txt")
	print("rewardPerNode"," is ",x)
	return x
def token():
	x = cont.functions.token().call()
	f.pen(x,"ask.txt")
	print("token"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalNodesCreated():
	x = cont.functions.totalNodesCreated().call()
	f.pen(x,"ask.txt")
	print("totalNodesCreated"," is ",x)
	return x
def totalStaked():
	x = cont.functions.totalStaked().call()
	f.pen(x,"ask.txt")
	print("totalStaked"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateBoostMultipliers(uint8ls_newVal):
	return cont.functions.updateBoostMultipliers(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateBoostRequiredDays(uint8ls_newVal):
	return cont.functions.updateBoostRequiredDays(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateMinPrice(uint256_newVal):
	return cont.functions.updateMinPrice(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateReward(uint8_newVal):
	return cont.functions.updateReward(uint8_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateToken(address_newToken):
	return cont.functions.updateToken(address_newToken).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def _calculateBoost(uint256__lastClaimTime):
	x = cont.functions._calculateBoost(uint256__lastClaimTime).call()
	f.pen(x,"ask.txt")
	print("_calculateBoost"," is ",x)
	return x
def _calculateNodeRewards(uint256__lastClaimTime,uint256__lastCompoundTime,uint256_amount):
	x = cont.functions._calculateNodeRewards(uint256__lastClaimTime,uint256__lastCompoundTime,uint256_amount).call()
	f.pen(x,"ask.txt")
	print("_calculateNodeRewards"," is ",x)
	return x
def cashoutAllNodesRewards(address_account):
	return cont.functions.cashoutAllNodesRewards(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutNodeReward(address_account,uint256__creationTime):
	return cont.functions.cashoutNodeReward(address_account,uint256__creationTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundAllNodesRewards(address_account):
	return cont.functions.compoundAllNodesRewards(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount):
	return cont.functions.compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNode(address_account,string_nodeName,uint256_amount):
	return cont.functions.createNode(address_account,string_nodeName,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getAllNodes(address_account):
	x = cont.functions.getAllNodes(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodes"," is ",x)
	return x
def getAllNodesAmount(address_account):
	x = cont.functions.getAllNodesAmount(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesAmount"," is ",x)
	return x
def getAllNodesRewards(address_account):
	x = cont.functions.getAllNodesRewards(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesRewards"," is ",x)
	return x
def getMinPrice():
	x = cont.functions.getMinPrice().call()
	f.pen(x,"ask.txt")
	print("getMinPrice"," is ",x)
	return x
def getNodeNumberOf(address_account):
	x = cont.functions.getNodeNumberOf(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodeNumberOf"," is ",x)
	return x
def getNodeReward(address_account,uint256__creationTime):
	x = cont.functions.getNodeReward(address_account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("getNodeReward"," is ",x)
	return x
def increaseNodeAmount(address_account,uint256__creationTime,uint256__amount):
	return cont.functions.increaseNodeAmount(address_account,uint256__creationTime,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def mergeNodes(address_account,uint256__creationTime1,uint256__creationTime2):
	return cont.functions.mergeNodes(address_account,uint256__creationTime1,uint256__creationTime2).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def migrateNodes(address_account):
	return cont.functions.migrateNodes(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def minPrice():
	x = cont.functions.minPrice().call()
	f.pen(x,"ask.txt")
	print("minPrice"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renameNode(address_account,string__newName,uint256__creationTime):
	return cont.functions.renameNode(address_account,string__newName,uint256__creationTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardPerNode():
	x = cont.functions.rewardPerNode().call()
	f.pen(x,"ask.txt")
	print("rewardPerNode"," is ",x)
	return x
def setAuthorized(address_account,bool_newVal):
	return cont.functions.setAuthorized(address_account,bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setBoostMultipliers(uint8ls_newVal):
	return cont.functions.setBoostMultipliers(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setBoostRequiredDays(uint8ls_newVal):
	return cont.functions.setBoostRequiredDays(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setMinPrice(uint256_newVal):
	return cont.functions.setMinPrice(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setRewardPerNode(uint256_newVal):
	return cont.functions.setRewardPerNode(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setToken(address_newToken):
	return cont.functions.setToken(address_newToken).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def token():
	x = cont.functions.token().call()
	f.pen(x,"ask.txt")
	print("token"," is ",x)
	return x
def totalNodesCreated():
	x = cont.functions.totalNodesCreated().call()
	f.pen(x,"ask.txt")
	print("totalNodesCreated"," is ",x)
	return x
def totalStaked():
	x = cont.functions.totalStaked().call()
	f.pen(x,"ask.txt")
	print("totalStaked"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def calculateNodeRewards(uint256__lastClaimTime,uint256__lastCompoundTime,uint256__amount):
	x = cont.functions.calculateNodeRewards(uint256__lastClaimTime,uint256__lastCompoundTime,uint256__amount).call()
	f.pen(x,"ask.txt")
	print("calculateNodeRewards"," is ",x)
	return x
def claimAllNodes(address__account):
	return cont.functions.claimAllNodes(address__account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def claimNode(address__account,uint256__creationTime):
	return cont.functions.claimNode(address__account,uint256__creationTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundAllNodes(address__account,uint256__fee):
	return cont.functions.compoundAllNodes(address__account,uint256__fee).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNode(address__account,uint256__creationTime,uint256__fee):
	return cont.functions.compoundNode(address__account,uint256__creationTime,uint256__fee).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNode(address__account,string__name,uint256__amount):
	return cont.functions.createNode(address__account,string__name,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getAllNodesRewards(address__account):
	x = cont.functions.getAllNodesRewards(address__account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesRewards"," is ",x)
	return x
def getBoostMultipliers():
	x = cont.functions.getBoostMultipliers().call()
	f.pen(x,"ask.txt")
	print("getBoostMultipliers"," is ",x)
	return x
def getBoostRequiredDays():
	x = cont.functions.getBoostRequiredDays().call()
	f.pen(x,"ask.txt")
	print("getBoostRequiredDays"," is ",x)
	return x
def getCompoundBonus(address__account,uint256__creationTime,uint256__fee):
	x = cont.functions.getCompoundBonus(address__account,uint256__creationTime,uint256__fee).call()
	f.pen(x,"ask.txt")
	print("getCompoundBonus"," is ",x)
	return x
def getCompoundMultipliers():
	x = cont.functions.getCompoundMultipliers().call()
	f.pen(x,"ask.txt")
	print("getCompoundMultipliers"," is ",x)
	return x
def getCompoundRequiredTokens():
	x = cont.functions.getCompoundRequiredTokens().call()
	f.pen(x,"ask.txt")
	print("getCompoundRequiredTokens"," is ",x)
	return x
def getMinTokensRequired():
	x = cont.functions.getMinTokensRequired().call()
	f.pen(x,"ask.txt")
	print("getMinTokensRequired"," is ",x)
	return x
def getNodeRewards(address__account,uint256__creationTime):
	x = cont.functions.getNodeRewards(address__account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("getNodeRewards"," is ",x)
	return x
def getNodeStorageAddress():
	x = cont.functions.getNodeStorageAddress().call()
	f.pen(x,"ask.txt")
	print("getNodeStorageAddress"," is ",x)
	return x
def getNodesCount(address__account):
	x = cont.functions.getNodesCount(address__account).call()
	f.pen(x,"ask.txt")
	print("getNodesCount"," is ",x)
	return x
def increaseNodeAmount(address__account,uint256__creationTime,uint256__amount):
	return cont.functions.increaseNodeAmount(address__account,uint256__creationTime,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def mergeNodes(address__account,uint256__destBlocktime,uint256__srcBlocktime):
	return cont.functions.mergeNodes(address__account,uint256__destBlocktime,uint256__srcBlocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def migrateNodes(address_account):
	return cont.functions.migrateNodes(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def minTokensRequired():
	x = cont.functions.minTokensRequired().call()
	f.pen(x,"ask.txt")
	print("minTokensRequired"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renameNode(address__account,uint256__creationTime,string__name):
	return cont.functions.renameNode(address__account,uint256__creationTime,string__name).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardPerNode():
	x = cont.functions.rewardPerNode().call()
	f.pen(x,"ask.txt")
	print("rewardPerNode"," is ",x)
	return x
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setBoostMultipliers(uint256ls_boostMultipliers):
	return cont.functions.setBoostMultipliers(uint256ls_boostMultipliers).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setBoostRequiredDays(uint256ls_boostRequiredDays):
	return cont.functions.setBoostRequiredDays(uint256ls_boostRequiredDays).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setCompoundMultipliers(uint256ls_compoundMultipliers):
	return cont.functions.setCompoundMultipliers(uint256ls_compoundMultipliers).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setCompoundRequiredTokens(uint256ls_compoundRequiredTokens):
	return cont.functions.setCompoundRequiredTokens(uint256ls_compoundRequiredTokens).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setMinTokensRequired(uint256__minTokensRequired):
	return cont.functions.setMinTokensRequired(uint256__minTokensRequired).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setNodeStorage(address__nodeStorage):
	return cont.functions.setNodeStorage(address__nodeStorage).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setRewardPerNode(uint256__rewardPerNode):
	return cont.functions.setRewardPerNode(uint256__rewardPerNode).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def totalNodesCreated():
	x = cont.functions.totalNodesCreated().call()
	f.pen(x,"ask.txt")
	print("totalNodesCreated"," is ",x)
	return x
def totalNodesMigrated():
	x = cont.functions.totalNodesMigrated().call()
	f.pen(x,"ask.txt")
	print("totalNodesMigrated"," is ",x)
	return x
def totalValueLocked():
	x = cont.functions.totalValueLocked().call()
	f.pen(x,"ask.txt")
	print("totalValueLocked"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def addAmount(address__account,uint256__creationTime,uint256__amount):
	return cont.functions.addAmount(address__account,uint256__creationTime,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNode(address__account,string__name,uint256__amount):
	return cont.functions.createNode(address__account,string__name,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getAllActiveNodes(address__account):
	x = cont.functions.getAllActiveNodes(address__account).call()
	f.pen(x,"ask.txt")
	print("getAllActiveNodes"," is ",x)
	return x
def getAllDeletedNodes(address__account):
	x = cont.functions.getAllDeletedNodes(address__account).call()
	f.pen(x,"ask.txt")
	print("getAllDeletedNodes"," is ",x)
	return x
def getAllNodes(address__account):
	x = cont.functions.getAllNodes(address__account).call()
	f.pen(x,"ask.txt")
	print("getAllNodes"," is ",x)
	return x
def getAllNodesAmount(address__account):
	x = cont.functions.getAllNodesAmount(address__account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesAmount"," is ",x)
	return x
def getNode(address__account,uint256__creationTime):
	x = cont.functions.getNode(address__account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("getNode"," is ",x)
	return x
def getNodesCount(address__account):
	x = cont.functions.getNodesCount(address__account).call()
	f.pen(x,"ask.txt")
	print("getNodesCount"," is ",x)
	return x
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def isNodeDeleted(address__account,uint256__creationTime):
	x = cont.functions.isNodeDeleted(address__account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("isNodeDeleted"," is ",x)
	return x
def migrateNode(address__account,string__name,uint256__amount,uint256__creationTime,uint256__lastClaimTime,uint256__lastCompoundTime):
	return cont.functions.migrateNode(address__account,string__name,uint256__amount,uint256__creationTime,uint256__lastClaimTime,uint256__lastCompoundTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setDeleted(address__account,uint256__creationTime,bool__isDeleted):
	return cont.functions.setDeleted(address__account,uint256__creationTime,bool__isDeleted).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setLastClaimTime(address__account,uint256__creationTime,uint256__timestamp):
	return cont.functions.setLastClaimTime(address__account,uint256__creationTime,uint256__timestamp).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setLastCompoundTime(address__account,uint256__creationTime,uint256__timestamp):
	return cont.functions.setLastCompoundTime(address__account,uint256__creationTime,uint256__timestamp).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setName(address__account,uint256__creationTime,string__name):
	return cont.functions.setName(address__account,uint256__creationTime,string__name).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def fees():
	x = cont.functions.fees().call()
	f.pen(x,"ask.txt")
	print("fees"," is ",x)
	return x
def getFees():
	x = cont.functions.getFees().call()
	f.pen(x,"ask.txt")
	print("getFees"," is ",x)
	return x
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def joePair():
	x = cont.functions.joePair().call()
	f.pen(x,"ask.txt")
	print("joePair"," is ",x)
	return x
def joeRouterAddress():
	x = cont.functions.joeRouterAddress().call()
	f.pen(x,"ask.txt")
	print("joeRouterAddress"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def payee(uint256_index):
	x = cont.functions.payee(uint256_index).call()
	f.pen(x,"ask.txt")
	print("payee"," is ",x)
	return x
def process():
	return cont.functions.process().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def release(address_account):
	return cont.functions.release(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def release(address_token,address_account):
	return cont.functions.release(address_token,address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def released(address_token,address_account):
	x = cont.functions.released(address_token,address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def released(address_account):
	x = cont.functions.released(address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardsPool():
	x = cont.functions.rewardsPool().call()
	f.pen(x,"ask.txt")
	print("rewardsPool"," is ",x)
	return x
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setAutomatedMarketMakerPair(address_pair,bool_value):
	return cont.functions.setAutomatedMarketMakerPair(address_pair,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setFees(tuple__fees):
	return cont.functions.setFees(tuple__fees).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setRewardsPool(address_newVal):
	return cont.functions.setRewardsPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setRewardsSwapStable(bool_newVal):
	return cont.functions.setRewardsSwapStable(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setRwSwapFee(uint256_newVal):
	return cont.functions.setRwSwapFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setSwapLiquify(bool_newVal):
	return cont.functions.setSwapLiquify(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setSwapTokensAmount(uint256_newVal):
	return cont.functions.setSwapTokensAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setTeamPool(address_newVal):
	return cont.functions.setTeamPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setTeamSwapStable(bool_newVal):
	return cont.functions.setTeamSwapStable(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def shares(address_account):
	x = cont.functions.shares(address_account).call()
	f.pen(x,"ask.txt")
	print("shares"," is ",x)
	return x
def stableAddress():
	x = cont.functions.stableAddress().call()
	f.pen(x,"ask.txt")
	print("stableAddress"," is ",x)
	return x
def swapLiquifyEnabled():
	x = cont.functions.swapLiquifyEnabled().call()
	f.pen(x,"ask.txt")
	print("swapLiquifyEnabled"," is ",x)
	return x
def swapTokensAmount():
	x = cont.functions.swapTokensAmount().call()
	f.pen(x,"ask.txt")
	print("swapTokensAmount"," is ",x)
	return x
def teamPool():
	x = cont.functions.teamPool().call()
	f.pen(x,"ask.txt")
	print("teamPool"," is ",x)
	return x
def tokenAddress():
	x = cont.functions.tokenAddress().call()
	f.pen(x,"ask.txt")
	print("tokenAddress"," is ",x)
	return x
def totalReleased(address_token):
	x = cont.functions.totalReleased(address_token).call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalReleased():
	x = cont.functions.totalReleased().call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalShares():
	x = cont.functions.totalShares().call()
	f.pen(x,"ask.txt")
	print("totalShares"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def DOMAIN_SEPARATOR():
	x = cont.functions.DOMAIN_SEPARATOR().call()
	f.pen(x,"ask.txt")
	print("DOMAIN_SEPARATOR"," is ",x)
	return x
def MINIMUM_LIQUIDITY():
	x = cont.functions.MINIMUM_LIQUIDITY().call()
	f.pen(x,"ask.txt")
	print("MINIMUM_LIQUIDITY"," is ",x)
	return x
def PERMIT_TYPEHASH():
	x = cont.functions.PERMIT_TYPEHASH().call()
	f.pen(x,"ask.txt")
	print("PERMIT_TYPEHASH"," is ",x)
	return x
def approve(address_spender,uint256_value):
	return cont.functions.approve(address_spender,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_to):
	return cont.functions.burn(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def factory():
	x = cont.functions.factory().call()
	f.pen(x,"ask.txt")
	print("factory"," is ",x)
	return x
def getReserves():
	x = cont.functions.getReserves().call()
	f.pen(x,"ask.txt")
	print("getReserves"," is ",x)
	return x
def initialize(address__token0,address__token1):
	return cont.functions.initialize(address__token0,address__token1).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def kLast():
	x = cont.functions.kLast().call()
	f.pen(x,"ask.txt")
	print("kLast"," is ",x)
	return x
def mint(address_to):
	return cont.functions.mint(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def permit(address_owner,address_spender,uint256_value,uint256_deadline,uint8_v,bytes32_r,bytes32_s):
	return cont.functions.permit(address_owner,address_spender,uint256_value,uint256_deadline,uint8_v,bytes32_r,bytes32_s).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def price0CumulativeLast():
	x = cont.functions.price0CumulativeLast().call()
	f.pen(x,"ask.txt")
	print("price0CumulativeLast"," is ",x)
	return x
def price1CumulativeLast():
	x = cont.functions.price1CumulativeLast().call()
	f.pen(x,"ask.txt")
	print("price1CumulativeLast"," is ",x)
	return x
def skim(address_to):
	return cont.functions.skim(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def swap(uint256_amount0Out,uint256_amount1Out,address_to,bytes_data):
	return cont.functions.swap(uint256_amount0Out,uint256_amount1Out,address_to,bytes_data).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def sync():
	return cont.functions.sync().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def token0():
	x = cont.functions.token0().call()
	f.pen(x,"ask.txt")
	print("token0"," is ",x)
	return x
def token1():
	x = cont.functions.token1().call()
	f.pen(x,"ask.txt")
	print("token1"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_to,uint256_value):
	return cont.functions.transfer(address_to,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFrom(address_from,address_to,uint256_value):
	return cont.functions.transferFrom(address_from,address_to,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def commissionPercentage():
	x = cont.functions.commissionPercentage().call()
	f.pen(x,"ask.txt")
	print("commissionPercentage"," is ",x)
	return x
def generateCommission(address__referral,address__sponsor,uint256__amount):
	return cont.functions.generateCommission(address__referral,address__sponsor,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getBalance(address__sponsor):
	x = cont.functions.getBalance(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getBalance"," is ",x)
	return x
def getEarnedCommissions(address__sponsor):
	x = cont.functions.getEarnedCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getEarnedCommissions"," is ",x)
	return x
def getPaidCommissions(address__sponsor):
	x = cont.functions.getPaidCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getPaidCommissions"," is ",x)
	return x
def getSponsor(address__referral):
	x = cont.functions.getSponsor(address__referral).call()
	f.pen(x,"ask.txt")
	print("getSponsor"," is ",x)
	return x
def getTokenAddress():
	x = cont.functions.getTokenAddress().call()
	f.pen(x,"ask.txt")
	print("getTokenAddress"," is ",x)
	return x
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def taxPool():
	x = cont.functions.taxPool().call()
	f.pen(x,"ask.txt")
	print("taxPool"," is ",x)
	return x
def totalReferralCommissions():
	x = cont.functions.totalReferralCommissions().call()
	f.pen(x,"ask.txt")
	print("totalReferralCommissions"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def withdrawCommision():
	return cont.functions.withdrawCommision().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("cashoutFee",":",cont.functions.cashoutFee().call())
	print("decimals",":",cont.functions.decimals().call())
	print("isTradingEnabled",":",cont.functions.isTradingEnabled().call())
	print("joePair",":",cont.functions.joePair().call())
	print("joeRouterAddress",":",cont.functions.joeRouterAddress().call())
	print("liquidityPoolFee",":",cont.functions.liquidityPoolFee().call())
	print("name",":",cont.functions.name().call())
	print("owner",":",cont.functions.owner().call())
	print("rewardsFee",":",cont.functions.rewardsFee().call())
	print("rewardsPool",":",cont.functions.rewardsPool().call())
	print("swapLiquifyEnabled",":",cont.functions.swapLiquifyEnabled().call())
	print("swapTokensAmount",":",cont.functions.swapTokensAmount().call())
	print("symbol",":",cont.functions.symbol().call())
	print("teamPool",":",cont.functions.teamPool().call())
	print("teamPoolFee",":",cont.functions.teamPoolFee().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalFees",":",cont.functions.totalFees().call())
	print("totalReleased",":",cont.functions.totalReleased().call())
	print("totalShares",":",cont.functions.totalShares().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	print("cashoutFee",":",cont.functions.cashoutFee().call())
	print("decimals",":",cont.functions.decimals().call())
	print("isTradingEnabled",":",cont.functions.isTradingEnabled().call())
	print("joePair",":",cont.functions.joePair().call())
	print("joeRouterAddress",":",cont.functions.joeRouterAddress().call())
	print("liquidityPoolFee",":",cont.functions.liquidityPoolFee().call())
	print("name",":",cont.functions.name().call())
	print("owner",":",cont.functions.owner().call())
	print("rewardsFee",":",cont.functions.rewardsFee().call())
	print("rewardsPool",":",cont.functions.rewardsPool().call())
	print("swapLiquifyEnabled",":",cont.functions.swapLiquifyEnabled().call())
	print("swapTokensAmount",":",cont.functions.swapTokensAmount().call())
	print("symbol",":",cont.functions.symbol().call())
	print("teamPool",":",cont.functions.teamPool().call())
	print("teamPoolFee",":",cont.functions.teamPoolFee().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalFees",":",cont.functions.totalFees().call())
	print("totalReleased",":",cont.functions.totalReleased().call())
	print("totalShares",":",cont.functions.totalShares().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	print("getMinPrice",":",cont.functions.getMinPrice().call())
	print("minPrice",":",cont.functions.minPrice().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("rewardPerNode",":",cont.functions.rewardPerNode().call())
	print("token",":",cont.functions.token().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalNodesCreated",":",cont.functions.totalNodesCreated().call())
	print("totalStaked",":",cont.functions.totalStaked().call())
	print("getMinPrice",":",cont.functions.getMinPrice().call())
	print("minPrice",":",cont.functions.minPrice().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("rewardPerNode",":",cont.functions.rewardPerNode().call())
	print("token",":",cont.functions.token().call())
	print("totalNodesCreated",":",cont.functions.totalNodesCreated().call())
	print("totalStaked",":",cont.functions.totalStaked().call())
	print("getBoostMultipliers",":",cont.functions.getBoostMultipliers().call())
	print("getBoostRequiredDays",":",cont.functions.getBoostRequiredDays().call())
	print("getCompoundMultipliers",":",cont.functions.getCompoundMultipliers().call())
	print("getCompoundRequiredTokens",":",cont.functions.getCompoundRequiredTokens().call())
	print("getMinTokensRequired",":",cont.functions.getMinTokensRequired().call())
	print("getNodeStorageAddress",":",cont.functions.getNodeStorageAddress().call())
	print("minTokensRequired",":",cont.functions.minTokensRequired().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("rewardPerNode",":",cont.functions.rewardPerNode().call())
	print("totalNodesCreated",":",cont.functions.totalNodesCreated().call())
	print("totalNodesMigrated",":",cont.functions.totalNodesMigrated().call())
	print("totalValueLocked",":",cont.functions.totalValueLocked().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("fees",":",cont.functions.fees().call())
	print("getFees",":",cont.functions.getFees().call())
	print("joePair",":",cont.functions.joePair().call())
	print("joeRouterAddress",":",cont.functions.joeRouterAddress().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("rewardsPool",":",cont.functions.rewardsPool().call())
	print("stableAddress",":",cont.functions.stableAddress().call())
	print("swapLiquifyEnabled",":",cont.functions.swapLiquifyEnabled().call())
	print("swapTokensAmount",":",cont.functions.swapTokensAmount().call())
	print("teamPool",":",cont.functions.teamPool().call())
	print("tokenAddress",":",cont.functions.tokenAddress().call())
	print("totalReleased",":",cont.functions.totalReleased().call())
	print("totalShares",":",cont.functions.totalShares().call())
	print("DOMAIN_SEPARATOR",":",cont.functions.DOMAIN_SEPARATOR().call())
	print("MINIMUM_LIQUIDITY",":",cont.functions.MINIMUM_LIQUIDITY().call())
	print("PERMIT_TYPEHASH",":",cont.functions.PERMIT_TYPEHASH().call())
	print("decimals",":",cont.functions.decimals().call())
	print("factory",":",cont.functions.factory().call())
	print("getReserves",":",cont.functions.getReserves().call())
	print("kLast",":",cont.functions.kLast().call())
	print("name",":",cont.functions.name().call())
	print("price0CumulativeLast",":",cont.functions.price0CumulativeLast().call())
	print("price1CumulativeLast",":",cont.functions.price1CumulativeLast().call())
	print("symbol",":",cont.functions.symbol().call())
	print("token0",":",cont.functions.token0().call())
	print("token1",":",cont.functions.token1().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	print("commissionPercentage",":",cont.functions.commissionPercentage().call())
	print("getTokenAddress",":",cont.functions.getTokenAddress().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("taxPool",":",cont.functions.taxPool().call())
	print("totalReferralCommissions",":",cont.functions.totalReferralCommissions().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0xF59de9276f2f2A24cB333C91475523f4f7603685"
abi = f.reader_C("abi_fold/"+str(add)+".json")
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)