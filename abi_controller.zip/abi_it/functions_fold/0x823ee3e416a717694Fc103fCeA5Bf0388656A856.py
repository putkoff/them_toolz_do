from web3 import Web3
import p_k as key
import json
import functions as f
def commissionPercentage():
	x = cont.functions.commissionPercentage().call()
	f.pen(x,"ask.txt")
	print("commissionPercentage"," is ",x)
	return x
def generateCommission(address__referral,address__sponsor,uint256__amount):
	return cont.functions.generateCommission(address__referral,address__sponsor,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getBalance(address__sponsor):
	x = cont.functions.getBalance(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getBalance"," is ",x)
	return x
def getEarnedCommissions(address__sponsor):
	x = cont.functions.getEarnedCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getEarnedCommissions"," is ",x)
	return x
def getPaidCommissions(address__sponsor):
	x = cont.functions.getPaidCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getPaidCommissions"," is ",x)
	return x
def getSponsor(address__referral):
	x = cont.functions.getSponsor(address__referral).call()
	f.pen(x,"ask.txt")
	print("getSponsor"," is ",x)
	return x
def getTokenAddress():
	x = cont.functions.getTokenAddress().call()
	f.pen(x,"ask.txt")
	print("getTokenAddress"," is ",x)
	return x
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def taxPool():
	x = cont.functions.taxPool().call()
	f.pen(x,"ask.txt")
	print("taxPool"," is ",x)
	return x
def totalReferralCommissions():
	x = cont.functions.totalReferralCommissions().call()
	f.pen(x,"ask.txt")
	print("totalReferralCommissions"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def withdrawCommision():
	return cont.functions.withdrawCommision().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("commissionPercentage",":",cont.functions.commissionPercentage().call())
	print("getTokenAddress",":",cont.functions.getTokenAddress().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("taxPool",":",cont.functions.taxPool().call())
	print("totalReferralCommissions",":",cont.functions.totalReferralCommissions().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0x823ee3e416a717694Fc103fCeA5Bf0388656A856"
abi = f.reader_C("abi_fold/"+str(add)+".json")
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)