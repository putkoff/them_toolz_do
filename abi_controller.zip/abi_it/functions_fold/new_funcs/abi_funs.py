from web3 import Web3
import p_k as key
import json
import functions as f
def DOMAIN_SEPARATOR():
	x = cont.functions.DOMAIN_SEPARATOR().call()
	f.pen(x,"ask.txt")
	print("DOMAIN_SEPARATOR"," is ",x)
	return x
def MINIMUM_LIQUIDITY():
	x = cont.functions.MINIMUM_LIQUIDITY().call()
	f.pen(x,"ask.txt")
	print("MINIMUM_LIQUIDITY"," is ",x)
	return x
def PERMIT_TYPEHASH():
	x = cont.functions.PERMIT_TYPEHASH().call()
	f.pen(x,"ask.txt")
	print("PERMIT_TYPEHASH"," is ",x)
	return x
def approve(address_spender,uint256_value):
	return cont.functions.approve(address_spender,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_to):
	return cont.functions.burn(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def factory():
	x = cont.functions.factory().call()
	f.pen(x,"ask.txt")
	print("factory"," is ",x)
	return x
def getReserves():
	x = cont.functions.getReserves().call()
	f.pen(x,"ask.txt")
	print("getReserves"," is ",x)
	return x
def initialize(address__token0,address__token1):
	return cont.functions.initialize(address__token0,address__token1).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def kLast():
	x = cont.functions.kLast().call()
	f.pen(x,"ask.txt")
	print("kLast"," is ",x)
	return x
def mint(address_to):
	return cont.functions.mint(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def permit(address_owner,address_spender,uint256_value,uint256_deadline,uint8_v,bytes32_r,bytes32_s):
	return cont.functions.permit(address_owner,address_spender,uint256_value,uint256_deadline,uint8_v,bytes32_r,bytes32_s).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def price0CumulativeLast():
	x = cont.functions.price0CumulativeLast().call()
	f.pen(x,"ask.txt")
	print("price0CumulativeLast"," is ",x)
	return x
def price1CumulativeLast():
	x = cont.functions.price1CumulativeLast().call()
	f.pen(x,"ask.txt")
	print("price1CumulativeLast"," is ",x)
	return x
def skim(address_to):
	return cont.functions.skim(address_to).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def swap(uint256_amount0Out,uint256_amount1Out,address_to,bytes_data):
	return cont.functions.swap(uint256_amount0Out,uint256_amount1Out,address_to,bytes_data).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def sync():
	return cont.functions.sync().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def token0():
	x = cont.functions.token0().call()
	f.pen(x,"ask.txt")
	print("token0"," is ",x)
	return x
def token1():
	x = cont.functions.token1().call()
	f.pen(x,"ask.txt")
	print("token1"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_to,uint256_value):
	return cont.functions.transfer(address_to,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFrom(address_from,address_to,uint256_value):
	return cont.functions.transferFrom(address_from,address_to,uint256_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def commissionPercentage():
	x = cont.functions.commissionPercentage().call()
	f.pen(x,"ask.txt")
	print("commissionPercentage"," is ",x)
	return x
def generateCommission(address__referral,address__sponsor,uint256__amount):
	return cont.functions.generateCommission(address__referral,address__sponsor,uint256__amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getBalance(address__sponsor):
	x = cont.functions.getBalance(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getBalance"," is ",x)
	return x
def getEarnedCommissions(address__sponsor):
	x = cont.functions.getEarnedCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getEarnedCommissions"," is ",x)
	return x
def getPaidCommissions(address__sponsor):
	x = cont.functions.getPaidCommissions(address__sponsor).call()
	f.pen(x,"ask.txt")
	print("getPaidCommissions"," is ",x)
	return x
def getSponsor(address__referral):
	x = cont.functions.getSponsor(address__referral).call()
	f.pen(x,"ask.txt")
	print("getSponsor"," is ",x)
	return x
def getTokenAddress():
	x = cont.functions.getTokenAddress().call()
	f.pen(x,"ask.txt")
	print("getTokenAddress"," is ",x)
	return x
def isAuthorized(address__address):
	x = cont.functions.isAuthorized(address__address).call()
	f.pen(x,"ask.txt")
	print("isAuthorized"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def pause():
	return cont.functions.pause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def setAuthorizedAddress(address__address,bool__value):
	return cont.functions.setAuthorizedAddress(address__address,bool__value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def taxPool():
	x = cont.functions.taxPool().call()
	f.pen(x,"ask.txt")
	print("taxPool"," is ",x)
	return x
def totalReferralCommissions():
	x = cont.functions.totalReferralCommissions().call()
	f.pen(x,"ask.txt")
	print("totalReferralCommissions"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def unpause():
	return cont.functions.unpause().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def withdrawCommision():
	return cont.functions.withdrawCommision().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("DOMAIN_SEPARATOR",":",cont.functions.DOMAIN_SEPARATOR().call())
	print("MINIMUM_LIQUIDITY",":",cont.functions.MINIMUM_LIQUIDITY().call())
	print("PERMIT_TYPEHASH",":",cont.functions.PERMIT_TYPEHASH().call())
	print("decimals",":",cont.functions.decimals().call())
	print("factory",":",cont.functions.factory().call())
	print("getReserves",":",cont.functions.getReserves().call())
	print("kLast",":",cont.functions.kLast().call())
	print("name",":",cont.functions.name().call())
	print("price0CumulativeLast",":",cont.functions.price0CumulativeLast().call())
	print("price1CumulativeLast",":",cont.functions.price1CumulativeLast().call())
	print("symbol",":",cont.functions.symbol().call())
	print("token0",":",cont.functions.token0().call())
	print("token1",":",cont.functions.token1().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	print("commissionPercentage",":",cont.functions.commissionPercentage().call())
	print("getTokenAddress",":",cont.functions.getTokenAddress().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("taxPool",":",cont.functions.taxPool().call())
	print("totalReferralCommissions",":",cont.functions.totalReferralCommissions().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0x2a3075686D167734a21C0003A0f584B068a5dC83"
abi = [{'inputs': [{'internalType': 'address', 'name': '_token', 'type': 'address'}, {'internalType': 'address', 'name': '_taxPool', 'type': 'address'}, {'internalType': 'uint256', 'name': '_commissionPercentage', 'type': 'uint256'}], 'stateMutability': 'nonpayable', 'type': 'constructor'}, {'anonymous': False, 'inputs': [{'indexed': True, 'internalType': 'address', 'name': 'sponsor', 'type': 'address'}, {'indexed': True, 'internalType': 'address', 'name': 'referral', 'type': 'address'}, {'indexed': False, 'internalType': 'uint256', 'name': 'commission', 'type': 'uint256'}, {'indexed': False, 'internalType': 'uint256', 'name': 'timestamp', 'type': 'uint256'}], 'name': 'Commision', 'type': 'event'}, {'anonymous': False, 'inputs': [{'indexed': True, 'internalType': 'address', 'name': 'previousOwner', 'type': 'address'}, {'indexed': True, 'internalType': 'address', 'name': 'newOwner', 'type': 'address'}], 'name': 'OwnershipTransferred', 'type': 'event'}, {'anonymous': False, 'inputs': [{'indexed': False, 'internalType': 'address', 'name': 'account', 'type': 'address'}], 'name': 'Paused', 'type': 'event'}, {'anonymous': False, 'inputs': [{'indexed': False, 'internalType': 'address', 'name': 'account', 'type': 'address'}], 'name': 'Unpaused', 'type': 'event'}, {'anonymous': False, 'inputs': [{'indexed': True, 'internalType': 'address', 'name': 'sponsor', 'type': 'address'}, {'indexed': False, 'internalType': 'uint256', 'name': 'balance', 'type': 'uint256'}], 'name': 'Withdraw', 'type': 'event'}, {'inputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'name': 'balances', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'commissionPercentage', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'name': 'earnedCommissions', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_referral', 'type': 'address'}, {'internalType': 'address', 'name': '_sponsor', 'type': 'address'}, {'internalType': 'uint256', 'name': '_amount', 'type': 'uint256'}], 'name': 'generateCommission', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_sponsor', 'type': 'address'}], 'name': 'getBalance', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_sponsor', 'type': 'address'}], 'name': 'getEarnedCommissions', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_sponsor', 'type': 'address'}], 'name': 'getPaidCommissions', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_referral', 'type': 'address'}], 'name': 'getSponsor', 'outputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'getTokenAddress', 'outputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_address', 'type': 'address'}], 'name': 'isAuthorized', 'outputs': [{'internalType': 'bool', 'name': '', 'type': 'bool'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'owner', 'outputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'name': 'paidCommissions', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'pause', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [], 'name': 'paused', 'outputs': [{'internalType': 'bool', 'name': '', 'type': 'bool'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'renounceOwnership', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '_address', 'type': 'address'}, {'internalType': 'bool', 'name': '_value', 'type': 'bool'}], 'name': 'setAuthorizedAddress', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'name': 'sponsors', 'outputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'taxPool', 'outputs': [{'internalType': 'address', 'name': '', 'type': 'address'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [], 'name': 'totalReferralCommissions', 'outputs': [{'internalType': 'uint256', 'name': '', 'type': 'uint256'}], 'stateMutability': 'view', 'type': 'function'}, {'inputs': [{'internalType': 'address', 'name': 'newOwner', 'type': 'address'}], 'name': 'transferOwnership', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [], 'name': 'unpause', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}, {'inputs': [], 'name': 'withdrawCommision', 'outputs': [], 'stateMutability': 'nonpayable', 'type': 'function'}]
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)