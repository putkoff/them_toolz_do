from web3 import Web3
import p_k as key
import json
import functions as f
def burn(uint256_index):
	return cont.functions.burn(uint256_index).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAllNodesRewards(address_account):
	return cont.functions.cashoutAllNodesRewards(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutNodeReward(address_account,uint256__creationTime):
	return cont.functions.cashoutNodeReward(address_account,uint256__creationTime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount):
	return cont.functions.compoundNodeReward(address_account,uint256__creationTime,uint256_rewardAmount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNode(address_account,string_nodeName,uint256_amount):
	return cont.functions.createNode(address_account,string_nodeName,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def getAllNodes(address_account):
	x = cont.functions.getAllNodes(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodes"," is ",x)
	return x
def getAllNodesRewards(address_account):
	x = cont.functions.getAllNodesRewards(address_account).call()
	f.pen(x,"ask.txt")
	print("getAllNodesRewards"," is ",x)
	return x
def getIndexOfKey(address_account):
	x = cont.functions.getIndexOfKey(address_account).call()
	f.pen(x,"ask.txt")
	print("getIndexOfKey"," is ",x)
	return x
def getMinPrice():
	x = cont.functions.getMinPrice().call()
	f.pen(x,"ask.txt")
	print("getMinPrice"," is ",x)
	return x
def getNodeNumberOf(address_account):
	x = cont.functions.getNodeNumberOf(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodeNumberOf"," is ",x)
	return x
def getNodeReward(address_account,uint256__creationTime):
	x = cont.functions.getNodeReward(address_account,uint256__creationTime).call()
	f.pen(x,"ask.txt")
	print("getNodeReward"," is ",x)
	return x
def getNodesCreationTime(address_account):
	x = cont.functions.getNodesCreationTime(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesCreationTime"," is ",x)
	return x
def getNodesLastClaimTime(address_account):
	x = cont.functions.getNodesLastClaimTime(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesLastClaimTime"," is ",x)
	return x
def getNodesNames(address_account):
	x = cont.functions.getNodesNames(address_account).call()
	f.pen(x,"ask.txt")
	print("getNodesNames"," is ",x)
	return x
def isNodeOwner(address_account):
	x = cont.functions.isNodeOwner(address_account).call()
	f.pen(x,"ask.txt")
	print("isNodeOwner"," is ",x)
	return x
def minPrice():
	x = cont.functions.minPrice().call()
	f.pen(x,"ask.txt")
	print("minPrice"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def paused():
	x = cont.functions.paused().call()
	f.pen(x,"ask.txt")
	print("paused"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardPerNode():
	x = cont.functions.rewardPerNode().call()
	f.pen(x,"ask.txt")
	print("rewardPerNode"," is ",x)
	return x
def token():
	x = cont.functions.token().call()
	f.pen(x,"ask.txt")
	print("token"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalNodesCreated():
	x = cont.functions.totalNodesCreated().call()
	f.pen(x,"ask.txt")
	print("totalNodesCreated"," is ",x)
	return x
def totalStaked():
	x = cont.functions.totalStaked().call()
	f.pen(x,"ask.txt")
	print("totalStaked"," is ",x)
	return x
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateBoostMultipliers(uint8ls_newVal):
	return cont.functions.updateBoostMultipliers(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateBoostRequiredDays(uint8ls_newVal):
	return cont.functions.updateBoostRequiredDays(uint8ls_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateMinPrice(uint256_newVal):
	return cont.functions.updateMinPrice(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateReward(uint8_newVal):
	return cont.functions.updateReward(uint8_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateToken(address_newToken):
	return cont.functions.updateToken(address_newToken).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("getMinPrice",":",cont.functions.getMinPrice().call())
	print("minPrice",":",cont.functions.minPrice().call())
	print("owner",":",cont.functions.owner().call())
	print("paused",":",cont.functions.paused().call())
	print("rewardPerNode",":",cont.functions.rewardPerNode().call())
	print("token",":",cont.functions.token().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalNodesCreated",":",cont.functions.totalNodesCreated().call())
	print("totalStaked",":",cont.functions.totalStaked().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0x0329232CBf089Dac8C942C68A7Ba3Dc81682Fcf9"
abi = f.reader_C("abi_fold/"+str(add)+".json")
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)