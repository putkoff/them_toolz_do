from web3 import Web3
import p_k as key
import json
import functions as f
def allowance(address_owner,address_spender):
	x = cont.functions.allowance(address_owner,address_spender).call()
	f.pen(x,"ask.txt")
	print("allowance"," is ",x)
	return x
def approve(address_spender,uint256_amount):
	return cont.functions.approve(address_spender,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def balanceOf(address_account):
	x = cont.functions.balanceOf(address_account).call()
	f.pen(x,"ask.txt")
	print("balanceOf"," is ",x)
	return x
def blacklistAddress(address_account,bool_value):
	return cont.functions.blacklistAddress(address_account,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_account,uint256_amount):
	return cont.functions.burn(address_account,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAll():
	return cont.functions.cashoutAll().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutFee():
	x = cont.functions.cashoutFee().call()
	f.pen(x,"ask.txt")
	print("cashoutFee"," is ",x)
	return x
def cashoutReward(uint256_blocktime):
	return cont.functions.cashoutReward(uint256_blocktime).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def createNodeWithTokens(string_name):
	return cont.functions.createNodeWithTokens(string_name).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def decreaseAllowance(address_spender,uint256_subtractedValue):
	return cont.functions.decreaseAllowance(address_spender,uint256_subtractedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def increaseAllowance(address_spender,uint256_addedValue):
	return cont.functions.increaseAllowance(address_spender,uint256_addedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def isTradingEnabled():
	x = cont.functions.isTradingEnabled().call()
	f.pen(x,"ask.txt")
	print("isTradingEnabled"," is ",x)
	return x
def joePair():
	x = cont.functions.joePair().call()
	f.pen(x,"ask.txt")
	print("joePair"," is ",x)
	return x
def joeRouterAddress():
	x = cont.functions.joeRouterAddress().call()
	f.pen(x,"ask.txt")
	print("joeRouterAddress"," is ",x)
	return x
def liquidityPoolFee():
	x = cont.functions.liquidityPoolFee().call()
	f.pen(x,"ask.txt")
	print("liquidityPoolFee"," is ",x)
	return x
def migrate(addressls_addresses_,uint256ls_balances):
	return cont.functions.migrate(addressls_addresses_,uint256ls_balances).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def node_amount():
	x = cont.functions.node_amount().call()
	f.pen(x,"ask.txt")
	print("node_amount"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def payee(uint256_index):
	x = cont.functions.payee(uint256_index).call()
	f.pen(x,"ask.txt")
	print("payee"," is ",x)
	return x
def release(address_account):
	return cont.functions.release(address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def release(address_token,address_account):
	return cont.functions.release(address_token,address_account).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def released(address_token,address_account):
	x = cont.functions.released(address_token,address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def released(address_account):
	x = cont.functions.released(address_account).call()
	f.pen(x,"ask.txt")
	print("released"," is ",x)
	return x
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardsFee():
	x = cont.functions.rewardsFee().call()
	f.pen(x,"ask.txt")
	print("rewardsFee"," is ",x)
	return x
def rewardsPool():
	x = cont.functions.rewardsPool().call()
	f.pen(x,"ask.txt")
	print("rewardsPool"," is ",x)
	return x
def setAutomatedMarketMakerPair(address_pair,bool_value):
	return cont.functions.setAutomatedMarketMakerPair(address_pair,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def shares(address_account):
	x = cont.functions.shares(address_account).call()
	f.pen(x,"ask.txt")
	print("shares"," is ",x)
	return x
def swapLiquifyEnabled():
	x = cont.functions.swapLiquifyEnabled().call()
	f.pen(x,"ask.txt")
	print("swapLiquifyEnabled"," is ",x)
	return x
def swapTokensAmount():
	x = cont.functions.swapTokensAmount().call()
	f.pen(x,"ask.txt")
	print("swapTokensAmount"," is ",x)
	return x
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def teamPool():
	x = cont.functions.teamPool().call()
	f.pen(x,"ask.txt")
	print("teamPool"," is ",x)
	return x
def teamPoolFee():
	x = cont.functions.teamPoolFee().call()
	f.pen(x,"ask.txt")
	print("teamPoolFee"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalFees():
	x = cont.functions.totalFees().call()
	f.pen(x,"ask.txt")
	print("totalFees"," is ",x)
	return x
def totalReleased(address_token):
	x = cont.functions.totalReleased(address_token).call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalReleased():
	x = cont.functions.totalReleased().call()
	f.pen(x,"ask.txt")
	print("totalReleased"," is ",x)
	return x
def totalShares():
	x = cont.functions.totalShares().call()
	f.pen(x,"ask.txt")
	print("totalShares"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_recipient,uint256_amount):
	return cont.functions.transfer(address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFrom(address_sender,address_recipient,uint256_amount):
	return cont.functions.transferFrom(address_sender,address_recipient,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateCashoutFee(uint256_newVal):
	return cont.functions.updateCashoutFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateIsTradingEnabled(bool_newVal):
	return cont.functions.updateIsTradingEnabled(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateLiquidityFee(uint256_newVal):
	return cont.functions.updateLiquidityFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateNodeAmount(uint256_newVal):
	return cont.functions.updateNodeAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsFee(uint256_newVal):
	return cont.functions.updateRewardsFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsPool(address_newVal):
	return cont.functions.updateRewardsPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRwSwapFee(uint256_newVal):
	return cont.functions.updateRwSwapFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapLiquify(bool_newVal):
	return cont.functions.updateSwapLiquify(bool_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateSwapTokensAmount(uint256_newVal):
	return cont.functions.updateSwapTokensAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamFee(uint256_newVal):
	return cont.functions.updateTeamFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamPool(address_newVal):
	return cont.functions.updateTeamPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("cashoutFee",":",cont.functions.cashoutFee().call())
	print("decimals",":",cont.functions.decimals().call())
	print("isTradingEnabled",":",cont.functions.isTradingEnabled().call())
	print("joePair",":",cont.functions.joePair().call())
	print("joeRouterAddress",":",cont.functions.joeRouterAddress().call())
	print("liquidityPoolFee",":",cont.functions.liquidityPoolFee().call())
	print("name",":",cont.functions.name().call())
	print("node_amount",":",cont.functions.node_amount().call())
	print("owner",":",cont.functions.owner().call())
	print("rewardsFee",":",cont.functions.rewardsFee().call())
	print("rewardsPool",":",cont.functions.rewardsPool().call())
	print("swapLiquifyEnabled",":",cont.functions.swapLiquifyEnabled().call())
	print("swapTokensAmount",":",cont.functions.swapTokensAmount().call())
	print("symbol",":",cont.functions.symbol().call())
	print("teamPool",":",cont.functions.teamPool().call())
	print("teamPoolFee",":",cont.functions.teamPoolFee().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalFees",":",cont.functions.totalFees().call())
	print("totalReleased",":",cont.functions.totalReleased().call())
	print("totalShares",":",cont.functions.totalShares().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0xce832d3e899cE4a1e7ebF886efFD098e6573c192"
abi = f.reader_C("abi_fold/"+str(add)+".json")
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)