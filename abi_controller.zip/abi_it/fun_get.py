import the_big_func as f
import functions as ff
import json
def get_event(x,y):
    global all_vars
    na = ['inputs','outputs']
    fun = 'event '+str(y)+'()'
    v =[]
    for i in range(0,len(na)):
        i_o = na[i]
        if i_o in x:
            for ii in range(0,len(x[i_o])):
                v.append(gen_index(f.js_it(f.t_f_js_check(x[i_o][ii]))))
            fun = f.get_list(fun,v)
    
    return str(fun).replace(')',');')
def gen_index(y):
    global all_vars
    n = ['indexed', 'internalType', 'name', 'type']
    z = y['type'] + ' '+y['name']
    if z not in all_vars:
        if y['name'] == '':
            if y['type'] not in types:
                types.append(z.replace(' ',''))
        else:
            if z not in all_vars:
                all_vars.append(z)
    if 'indexed' in y:
        if y['indexed'] == 'False':
            if z not in non_varis:
                non_varis.append(z)
        else:
            z = y['type'] + ' indexed '+y['name']
            if z not in ind_varis:
                ind_varis.append(z)
    return z
#abi = f.reader_C('utils/abi.txt').replace('\n','').replace(' ','')
global kek_funs,fun_calls,ind_varis,non_varis,funs,event,const,maps,all_vars
kek_funs,fun_calls,ind_varis,non_varis,funs,event,const,maps,all_vars,types = [],[],[],[],[],[],[],[],[],[]

def go(add,abi):
    varis = f.js_it('{"all":[],"types":[],"indexed":[],"non_indexed":[]}')

    for i in range(0,len(abi)):
        n = abi[i]
        na = ['inputs','outputs']
        ls = f.js_it('{}')
        name,typ = '',''
        maping = 0
        ll = ''
        if 'name' in n:
            name = n['name']
            fun_calls.append(name)
        if 'stateMutability' in n:
            mute = n['stateMutability']
        if 'type' in n:
            typ = n['type']
        if 'inputs' in n:
            if str(n['inputs']) != '[]':
                if n['inputs'][0]['name'] == '':
                    maping = 1
        ls = f.js_it(str(ls)[:-1] + f.get_c(len(ls)) + str(f.js_qu(name)+':{}')+str(ls)[-1])
        if int(maping) == int(0) and typ == 'function':
            for ii in range(0,len(na)):
                n_na = na[ii]
                ns = f.join_it(f.js_qu(n_na),':[]')
                ls[name] = f.js_it(str(ls[name])[:-1] + f.get_c(len(ls[name])) + str(ns)+str(ls[name])[-1])
                for iii in range(0,len(n[n_na])):
                    ls[name][n_na].append(gen_index(n[n_na][iii]))
                if str(n_na) in str(n) and str(n[n_na]) != '[]':
                    n_y = f.t_f_js_check(n[n_na][0])
                    y = f.js_it(n_y)
            funs.append(f.get_fun(ls,name,mute))
        elif typ == 'constructor':
            const.append(str(typ)+'(){};')
        elif typ == 'event':
            event.append(get_event(n,name))
        elif int(maping) == int(1) and typ == 'function':
            maps.append(f.get_map(n,name))
add = ff.check_sum(ff.reader_C('curr_add.txt').replace('\n',''))
abi = json.loads(f.reader_C('abi_fold/'+str(add)+'.json'))
go(add,abi)

