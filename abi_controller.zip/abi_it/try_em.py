import abi_funs
abi_funs.add = 0x2a3075686D167734a21C0003A0f584B068a5dC83
try:
	abi_funs.view_all()
except:
	print("no_good")
