
import functions as f

import json
import os
#import BNN_abi as bn
alph = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz,aaa,bbb,ccc,ddd,eee,fff,ggg,hhh,iii,jjj,kkk,lll,mmm,nnn,ooo,ppp,qqq,rrr,sss,ttt,uuu,vvv,www,xxx,yyy,zzz'

import functions as f
def list_files(x):
    return os.listdir(x)
def imp_it():
    import abi_funs as a
    return a
def get_abi():
    return f.sites('https://'+str(scanners)+'/api?module=contract&action=getabi&address='+str(add)+'&apikey='+str(api_key())) 
def api_key():
    if scanners == 'bscscan.com':
        x = 'JYVRVFFC32H2ZSKDY1JZKNY7XV1Y5MCJHM'
    elif scanners == 'polygonscan.com':
        x = 'S6X6NY29X4ARWRVSIZJTG1PJS4IG86B3WJ'
    elif scanners == 'ftmscan.com':
        x = 'WU2C3NZAQC9QT299HU5BF7P8QCYX39W327'
    elif scanners == 'moonbeam.moonscan.io':
        x = '5WVKC1UGJ3JMWQZQAT8471ZXT3UJVFDF4N'
    else:
        x = '4VK8PEWQN4TU4T5AV5ZRZGGPFD52N2HTM1'
    return x
def make_abi():
    file = 'abi_fold/'+str(add)+'.json'
    get = get_abi()
    f.pen(get,file)
def view_funs():
    for i in range(0,len(name_ls)):
        global add
        add = f.check_sum(add_js[name_ls[i]])
        fun_file = 'functions_fold/'+str(add)+'.py'
        f.copy_it(fun_file,os.getcwd(),'abi_funs.py')
        a_fun = list_files('functions_fold/')
        for i in range(0,len(a_fun)):
            f.copy_it(fun_file,os.getcwd(),'abi_funs.py')
            f.pen('import abi_funs as ab\nab.view_all()','hold.py')
            import hold
            return hold
def get_funs(i):
    import fun_get as fun
    import parse_funs as parse
    global add
    varis = f.js_it(f.reader_C('variables/varis.json'))
    name_ls,add_js = varis['name_ls'],varis['add_js']
    scanners,net,ch_id,main_tok,file,w3,network = f.mains()
    add = f.check_sum(add_js[name_ls[i]])
    f.pen(add,'curr_add.py')
    funs = fun.go(add,json.loads(f.reader_C('abi_fold/'+str(add)+'.json')))
    fun.add = f.check_sum(add)
    funs,asks,call,fun_all,fun_sheet = parse.parse_it(add)
    f.pen(fun_sheet,'functions_fold/'+str(add)+'.py')
def get_abis():
    for i in range(0,len(name_ls)):
        global add
        add = f.check_sum(add_js[name_ls[i]])
        get_abi()
        make_abi()
global add,scanners,name_ls,add_js



  
