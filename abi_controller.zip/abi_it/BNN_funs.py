from web3 import Web3
import p_k as key
import json
def reader_C(file):
	with open(file, "r",encoding="utf-8-sig") as f:
		text = f.read()
		return text
def mains(x):
	global net,ch_id,main,file,w3,last_api,c_k,hashs_js,expo,dec
	hashs_js = ""
	last_api = [0,0]
	scan = ["avax","polygon","ethereum","cronos_test","optimism","binance"]
	main = {
		"avax":{"net":"https://api.avax-test.network/ext/bc/C/rpc","chain":"43113","main":"AVAX"},
		"polygon":{"net":"https://polygon-rpc.com/","chain":"137","main":"MATIC"},
		"ethereum":{"net":"https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161","chain":"1","main":"ETH"},
		"cronos_test":{"net":"https://cronos-testnet-3.crypto.org:8545/","chain":"338","main":"TCRO"},
		"optimism":{"net":"https://kovan.optimism.io","chain":"69","main":"OPT"},
		"binance":{"net":"https://bsc-dataseed.binance.org/","chain":"56","main":"bsc"}
		}
	expo = ""
	dec = ""
	main = main[x]
	net,ch_id,main,file,w3 = main["net"],main["chain"],main["main"],str(x)+".txt",Web3(Web3.HTTPProvider(main["net"]))
	c_k = 0
	return net,ch_id,main,file,w3
def cashoutAll():
	return cont.functions.cashoutAll().call()
def cashoutFee():
	return cont.functions.cashoutFee().call()
def decimals():
	return cont.functions.decimals().call()
def isTradingEnabled():
	return cont.functions.isTradingEnabled().call()
def joePair():
	return cont.functions.joePair().call()
def joeRouterAddress():
	return cont.functions.joeRouterAddress().call()
def liquidityPoolFee():
	return cont.functions.liquidityPoolFee().call()
def name():
	return cont.functions.name().call()
def owner():
	return cont.functions.owner().call()
def renounceOwnership():
	return cont.functions.renounceOwnership().call()
def rewardsFee():
	return cont.functions.rewardsFee().call()
def rewardsPool():
	return cont.functions.rewardsPool().call()
def swapLiquifyEnabled():
	return cont.functions.swapLiquifyEnabled().call()
def swapTokensAmount():
	return cont.functions.swapTokensAmount().call()
def symbol():
	return cont.functions.symbol().call()
def teamPool():
	return cont.functions.teamPool().call()
def teamPoolFee():
	return cont.functions.teamPoolFee().call()
def totalClaimed():
	return cont.functions.totalClaimed().call()
def totalFees():
	return cont.functions.totalFees().call()
def totalReleased():
	return cont.functions.totalReleased().call()
def totalShares():
	return cont.functions.totalShares().call()
def totalSupply():
	return cont.functions.totalSupply().call()
def allowance(address_owner,address_spender):
	return cont.functions.allowance(address_owner,address_spender).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def approve(address_spender,uint256_amount):
	return cont.functions.approve(address_spender,uint256_amount).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def balanceOf(address_account):
	return cont.functions.balanceOf(address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def blacklistAddress(address_account,bool_value):
	return cont.functions.blacklistAddress(address_account,bool_value).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def burn(address_account,uint256_amount):
	return cont.functions.burn(address_account,uint256_amount).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def cashoutReward(uint256_blocktime):
	return cont.functions.cashoutReward(uint256_blocktime).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def compoundNodeRewards(uint256_blocktime):
	return cont.functions.compoundNodeRewards(uint256_blocktime).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def createNodeWithTokens(string_name,uint256_amount_):
	return cont.functions.createNodeWithTokens(string_name,uint256_amount_).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def decreaseAllowance(address_spender,uint256_subtractedValue):
	return cont.functions.decreaseAllowance(address_spender,uint256_subtractedValue).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def increaseAllowance(address_spender,uint256_addedValue):
	return cont.functions.increaseAllowance(address_spender,uint256_addedValue).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def migrate(address_addresses_,uint256_balances_):
	return cont.functions.migrate(address_addresses_,uint256_balances_).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def payee(uint256_index):
	return cont.functions.payee(uint256_index).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def release(address_account):
	return cont.functions.release(address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def release(address_token,address_account):
	return cont.functions.release(address_token,address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def released(address_token,address_account):
	return cont.functions.released(address_token,address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def released(address_account):
	return cont.functions.released(address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def setAutomatedMarketMakerPair(address_pair,bool_value):
	return cont.functions.setAutomatedMarketMakerPair(address_pair,bool_value).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def shares(address_account):
	return cont.functions.shares(address_account).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def totalReleased(address_token):
	return cont.functions.totalReleased(address_token).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def transfer(address_recipient,uint256_amount):
	return cont.functions.transfer(address_recipient,uint256_amount).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def transferFrom(address_sender,address_recipient,uint256_amount):
	return cont.functions.transferFrom(address_sender,address_recipient,uint256_amount).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateCashoutFee(uint256_newVal):
	return cont.functions.updateCashoutFee(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateIsTradingEnabled(bool_newVal):
	return cont.functions.updateIsTradingEnabled(bool_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateLiquidityFee(uint256_newVal):
	return cont.functions.updateLiquidityFee(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateRewardsFee(uint256_newVal):
	return cont.functions.updateRewardsFee(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateRewardsPool(address_newVal):
	return cont.functions.updateRewardsPool(address_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateRwSwapFee(uint256_newVal):
	return cont.functions.updateRwSwapFee(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateSwapLiquify(bool_newVal):
	return cont.functions.updateSwapLiquify(bool_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateSwapTokensAmount(uint256_newVal):
	return cont.functions.updateSwapTokensAmount(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateTeamFee(uint256_newVal):
	return cont.functions.updateTeamFee(uint256_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})
def updateTeamPool(address_newVal):
	return cont.functions.updateTeamPool(address_newVal).buildTransaction({'gasPrice': 25000000000,'gas':212640,'from': account_1.address,'nonce': w3.eth.getTransactionCount(account_1.address),'chainId': int(ch_id)})

global add,abi,cont,account_1,net,ch_id,main,file,w3
add = "0x954dC860ef3F7fd99519c0D6ed0ed1173a4b2064"
abi = json.loads(reader_C("abi.txt").replace("'",'"'))
main_all = mains("avax")
net,ch_id,main,file,w3 = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
