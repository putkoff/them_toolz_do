import functions as f
from web3 import Web3
import p_k as key
import fun_get as fun
import functions as f
import parse_funs as parse
import json
import clipboard
import webbrowser
import subprocess
import os
import imps
def exists(x):
    try:
        x = f.reader_C(x)
        return True
    except:
        return False
def exists_make(x,y):
    if exists(y) == False:
        f.pen(x,y)
        return x
    else:
        return f.reader_C(y)
def make_all_sheets():
        f.pen(f.check_sum(add),'curr_adds.txt')
        abi = exists_make(get_abi(),'abi_fold/'+str(add)+'.json')

        fun.go(add,abi)
    
        funs,asks,call,fun_all,fun_sheet = parse.parse_it(fun.add)
        f.pen(fun_sheet,'functions_fold/'+str(fun.add)+'.py')

def make_fun_sheets():
        fun_file = 'functions_fold/'+str(add)+'.py'
        funs,asks,call,fun_all,fun_sheet = parse.parse_it(add)
        f.pen(fun_sheet,fun_file)
def make_all_abi():
        #fun_file = 'functions_fold/'+str(add)+'.py'
        abi_file = 'abi_fold/'+str(add)+'.json'
        #x = f.reader_B(fun_file)
        #f.pen(x,'abi_funs.py')
        #x = f.reader_B(abi_file)
        x = get_abi()
        f.pen(x,'abi.txt')
        return f.js_it(x)
def make_abi():
    file = 'abi_fold/'+str(add)+'.json'
    get = get_abi()
    f.pen(get,file)
    #make_fun_sheets()
def print_scan():
    spl = 'api.'
    if 'api-' in scanners:
        li = scanners.split(spl.replace('.','-'))[1]
    print('https://'+li+'/address/'+str(add))
    clipboard.copy('https://'+li+'/address/'+str(add))
    return 'https://'+li
def get_hash(x):
    spl = 'api.'
    if 'api-' in scanners:
        li = scanners.split(spl.replace('.','-'))[1]
    print('https://'+li+'/tx/'+str(x))
    clipboard.copy('https://'+li+'/tx/'+str(x))
    return 'https://'+li
def get_abi():
    return f.sites('https://'+str(scanners)+'/api?module=contract&action=getabi&address='+str(add)+'&apikey='+str(api_key())) 
def api_key():
    if scanners == 'bscscan.com':
        x = 'JYVRVFFC32H2ZSKDY1JZKNY7XV1Y5MCJHM'
    elif scanners == 'polygonscan.com':
        x = 'S6X6NY29X4ARWRVSIZJTG1PJS4IG86B3WJ'
    elif scanners == 'ftmscan.com':
        x = 'WU2C3NZAQC9QT299HU5BF7P8QCYX39W327'
    elif scanners == 'moonbeam.moonscan.io':
        x = '5WVKC1UGJ3JMWQZQAT8471ZXT3UJVFDF4N'
    else:
        x = '4VK8PEWQN4TU4T5AV5ZRZGGPFD52N2HTM1'
    return x
def decimal():
    try:
        dec = cont.functions.decimals().call()
        return dec
    except:
        return 18
def check_sum(x):
    return w3.toChecksumAddress(x) 
def send_it(ans):
    tx = f.js_it(ans)
    tx["nonce"] = w3.eth.getTransactionCount(check_sum(tx['from']))
    tx['gas'] = w3.eth.estimateGas({'to': check_sum(tx['to']), 'from': check_sum(tx['from']), 'value': tx['value']})
    tx["gas"] = tx["gas"]+tx["gas"]
    tx["gasPrice"] = tx["gasPrice"]+tx["gasPrice"]
    signed_tx = w3.eth.account.sign_transaction(tx, key.p)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(tx_hash.hex())
def find_it(x,k):
    i = 0
    while str(x[i]) != str(k):
        i = i + 1
    return i
def get_alph():
    alph = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz,aaa,bbb,ccc,ddd,eee,fff,ggg,hhh,iii,jjj,kkk,lll,mmm,nnn,ooo,ppp,qqq,rrr,sss,ttt,uuu,vvv,www,xxx,yyy,zzz'
    return alph.split(',')
def create_abi(x):
    go = 2
    while go == 2:
        alph = get_alph()
        n = '\nwhich contract would you like to use?\n0) to exit\n1) to choose new network\n2) to change wallets\n'
        for i in range(0,len(x)):
            n = n + str(alph[i])+') '+str(x[i])+'\n'
        ask = input(n)
        if str(ask) == '0':
            return 'exit'
        if str(ask) == '1':
            f.rem_var()
            return 'new'
        if str(ask) == '2':
            envs = 'main','poor','tester','migrate'
            for i in range(0,len(envs)):
                n = n + str(alph[i])+') '+str(envs[i])+'\n'
            ask_env = input(n)
            k_env = int(find_it(alph,str(ask_env)))
            f.pen('.env_'+envs[k_env],'new_key.txt')
            global key
            import p_k as key
            go = 2
        else:
            go = 1
    
    k = int(find_it(alph,str(ask)))
    return k
def go():
        expo = float(1e-18)
        api = api_key()
        exi = create_abi(name_ls)
        print(exi,name_ls)
        if str(exi) == 'exit':
            return
        if str(exi) != 'new':
            global add,dec 
            name = name_ls[exi]
            add = f.check_sum(str(add_js[name]))
            dec = decimal()
            try:
                f.make_dir('functions_fold/'+str(name))
            except:
                print()
            path = 'functions_fold/'+str(name)+'/'
            fun_file = 'functions_fold/'+str(add)+'.py'
            fun_og_file = 'functions_fold/'+str(name)+'/'+str(add)+'.py'
            fun_ab_file = 'functions_fold/'+str(name)+'/abi_funs.py'
            abi_file = 'abi_fold/'+str(add)+'.json'
            print(fun_ab_file)
            
            #f.pen(abi_file,'functions_fold/'+str(name)+'/'+str(add)+'.json')
            fun = f.reader_C(fun_file)
            abi = f.reader_C(abi_file)
            funs,asks,call,fun_all,fun_sheet = parse.parse_it(add)
            abi = f.reader_C(abi_file)
            func = f.reader_C(fun_file)
            f.pen(fun_sheet,'abi_funs.py')
            f.pen(fun_sheet,'functions_fold/'+str(add)+'.py')
            f.pen(fun_sheet,'functions_fold/'+str(name)+'/abi_funs.py')
            f.pen(fun_sheet,'functions_fold/'+str(name)+'/'+str(add)+'.py')
            f.pen('import functions_fold.'+str(name)+'.abi_funs as funies','abi_funs.py')
            f.copy_it(fun_ab_file,os.getcwd(),'abi_funs.py')
            import abi_funs as a_fun
            a_fun.view_all()
            if str(exi) == 'exit':
                exit()
            if str(exi) != 'new':
                scanner_url = print_scan()
                abi = make_all_abi()
                account_1 = w3.eth.account.privateKeyToAccount(key.p)
                cont = w3.eth.contract(add,abi = abi)
                dec = decimal()
                
                ex = ''
                while ex != 'exit':
                    ex = input('would you like to view all viewable variables in the contract?')
                    if str(ex).lower() != 'n' and str(ex).lower() != 'no':
                            a_fun.view_all()
                    f.pen(fun_sheet,fun_file)
                    ex = create_inp(call)
def create_inp(x):
    scanner_url = print_scan()
    ask = -1
    alph = get_alph()
    n = '\nwhich function would you like to use?\n0) to choose new contract\n'
    for i in range(0,len(x)):
        if 'funs.' not in x[i]:
            x[i] = 'funs.'+x[i]
        n = n + str(alph[i])+') '+str(x[i].split('funs.')[1])+'\n'
    ask = input(n)
    if str(ask) == '0':
        os.remove('abi_funs.py')
        return 'exit'
    k = int(find_it(alph,str(ask)))
    print('going')
    
    if '()' not in str(x[k]):
        og = x[k].split('(')[0]+'('
        print(og)
        n = x[k].split('(')[1].split(')')[0].split(',')
        if type(n) is not list:
            n = [n]
        inp = []
        print('inputs for '+str(x[k].split('funs.')[1]))
        for i in range(0,len(n)):
            n_a = n[i]
            ad = ''
            n_d = n[i].split('_')[0]
            n_z  = n[i].split('_')[1]
            if n[i].split('_')[0][-2:] == 'ls':
                ad = ' as list'
                n_d = n[i].split('_')[0][:-2]
                n_a = n_a.replace(n[i].split('_')[0]+'_',n[i].split('_')[0][:-2]+'_')
            if 'address' in n_d:
                ask = input(' please input '+str(n_a)+ad)
                nn = f.check_sum(str(ask))
            elif 'uint' in n_d:
                if 'uint256' in n_d and 'blocktime' not in n_z :
                    ok = 'n'
                    while str(ok).lower() == 'n' or str(ok).lower() == 'no':
                        ask = input(' please input '+str(n_a)+ad+' (input will be multiplied by 10^'+str(int(dec))+' if * is added to the end of the input): ')
                        if '*' in str(ask):
                            ask = int(float(int(ask.split('*')[0]))*float(str('1e'+str(int(dec)))))
                        ok = input('your input is '+str(int(ask))+' is that ok?')
                    nn = int(ask)
                        
                else:
                    ask = input(' please input '+str(n_a)+ad)
                    nn = int(ask)
            elif 'bool' in n_d:
                ask = input(' please input '+str(n_a)+ad)
                if str(ask) == '1':
                    nn = True
                else:
                    nn = False
            else:
                ask = input(' please input '+str(n_a)+ad)
                nn = str(ask)
            if ad != '':
                nn = [nn]
            inp.append(nn)
        og = og +str(inp)[1:-1]+')'
    else:
        og = str(x[k])
    f.pen('import abi_funs as funs\nimport functions as f\ndef pen(paper, place):\n\twith open(place, "w") as f:\n\t\tf.write(str(paper))\n\t\tf.close()\n\t\treturn\ntxt = None\ninp = "'+str(og).split('(')[1].split(')')[0]+'"\nif inp == "":\n\t'+og+'\n\tpen(txt,"answer.txt")\nelse:\n\task = input("did you want to send this? '+str(og).split('(')[0]+','+str(og).split('(')[1].split(')')[0]+'?")\n\tif str(ask).lower() != "n" and str(ask).lower() != "no":\n\t\ttxt = str('+og+')\n\t\tpen(txt,"answer.txt")','do_it.py')
    import do_it as do 
    ans = f.reader('answer.txt')
    print('going')
    print(k)
    if str(ans) != 'None':
        #send_it(ans)
        print('going')
        tx = json.loads(str(do.txt).replace("'",'"'))
        tx["nonce"] = w3.eth.getTransactionCount(f.check_sum(tx['from']))
        tx["gas"] = tx["gas"]+tx["gas"]
        tx["gasPrice"] = tx["gasPrice"]+tx["gasPrice"]
        print(tx)
        signed_tx = w3.eth.account.sign_transaction(tx, key.p)
        tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
        print('going')
        p = subprocess.Popen(["firefox", str(scanner_url)+'/tx/'+str(tx_hash.hex())])
        get_hash(str(tx_hash.hex()))
#make_all_sheets()
#abi_file = 'abi_fold/'+str(add)+'.json'
#f.copy_it(fun_file,)
#f.pen(add,'curr_add.txt')\

global cont,dec,api,scanners,net,ch_id,main_tok,file,w3,network,add,name_ls,add_js,abi_file,account_1,funs,asks,call,fun_all,fun_sheet,network,fun_file,scanner_url,ad
f.rem_var()
exi = ''
varis = f.js_it(f.reader_C('variables/varis.json'))
name_ls,add_js = varis['name_ls'],varis['add_js']
scanners,net,ch_id,main_tok,file,w3,network = f.mains()

global add
for i in range(0,len(name_ls)):
    add = f.check_sum(add_js[name_ls[i]])
    make_all_abi()
    make_all_sheets()
    make_fun_sheets()
    
   
    
while True:               
    go()
