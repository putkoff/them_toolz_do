from web3 import Web3, HTTPProvider
import statistics
def check_sum(x):
    return Web3.toChecksumAddress(str(x))
web3 = Web3(HTTPProvider("https://api.avax-test.network/ext/bc/C/rpc"))
estimate = web3.eth.estimateGas({'to': check_sum('0x954dC860ef3F7fd99519c0D6ed0ed1173a4b2064'), 'from': check_sum('0x6876abb2758c43226506b5f41734f3a170c715aa'), 'value': 0})
print(estimate)
