import os
import json
def reader(file):
    with open(file, 'r') as f:
        text = f.read()
        return text
import sys
import functions as f
import time
def go_check(w,x,y,z):
    if in_check(w,x) == True:
        return True
    return False
    
def in_check(x,y):
    l = len(str(x))
    if type(y) is not list:
        y = [y]
    for i in range(0,len(y)):
        if str(x) in str(y[i])[:l-1]:
            
            if l == len(y[i]):
                
                return False
            return True
    return False
def go_str_check(w,x):
    if str_check(w,x) == True:
        return True
    return False
def str_check(x,y):
    if type(y) is not list:
        y = [y]
    if x in y:
        return True
    return False
def check_str(x,y):
    c = ''
    if str(x) != str(y):
        c = y
    return c
def create_path(x,y):
    return str(x) + str(check_str(x[-1],slash))+str(y)
def flatten_it(x):
    pa = create_path(all_dirs['terminal'],str(name_all)+'build_up.txt')
    f.pen('cd '+all_dirs['solidity-flattener'].split('Desktop')[1]+'; npm start "'+str(x)+'";',pa)
    bash_it(pa)
    return pa
def bash_it(x):
    global name_all,cou
    save = f.exists_make('',(create_path(all_dirs['terminal'],'split_build_up.txt'))) + str(x) + ' >> '+create_path(all_dirs['terminal'],str(name_all)+'.txt')+';'
    f.pen(save,create_path(all_dirs['terminal'],'split_build_up.txt'))
def bash_it_good(pa):
    global name_all,cou
    x = f.reader(pa)
    sh_str = f.reader(create_path(all_dirs['samples'],'samplesh.txt'))
    f.pen(sh_str.replace('^^killme^^',x+'echo im done >> '+str(pa)+'; exit;'),create_path(all_dirs['bash'],'script.sh'))
    gnome = "gnome-terminal -x ./bash/script.sh"
    p = os.popen(gnome ).read()
    while 'im done' not in f.read_lines(pa)[-1]:
        time.sleep(2)
        print('waiting for exit')
    
    f.pen(f.reader(pa).replace('im done','ended'),pa)
    speak = f.read_lines(pa)
    if len(speak) < int(10):
        x = speak
    else:
        x = speak[-10:-1]
    for i in range(0,len(x)):
        if str(x[i]) != '\n':
            print(x[i].replace('\n',''))
def change_places(x,y,z):
     x = str(x)[:-1]+',"'+y+'":"'+z+'"}'
     x = json.loads(x.replace('{,','{').replace("'",'"'))
     return x
def go_parent():
    places = json.loads('{}')
    count = len(os.getcwd()) - len(os.getcwd().replace('/',''))
    for i in range(0,count):
        os.chdir("..")
        path =str(os.getcwd()).split('/')[-1]
        places = change_places(places,path,os.getcwd())
    return places
def find_it(x,y):
    for i in range(0,len(x)):
        if y == x[i]:
            return i
    return False
def find_be(x,k):
    for i in range(0,len(x)):
        if k < x[i]:
            return x[i-1]
def find_em(x,y):
    
    m = []
    cou = 0
    for i, line in enumerate(x, 1):
        if y in line:
            cou = 1
            
            m.append(i-1)
            
    if cou == 0:
        return 0
    return m
def get_range_funs(w,y,z,i,u):
    x = y
    new = []
    if i < len(w)-1:
        x = find_be(u,w[i+1])+1
    more = return_range(y,x,z)
    for i in range(0,len(more[y:x])):
        new.append(more[y:x])
    return more[y:x]
def get_range(w,y,z,i,u):
    x = y
    if i == len(w)-1:
        print(u[-1])
        more = return_range(y,u[-1]+1,z)
    elif i < len(w):
         x = find_be(u,w[i+1])
        
         more = return_range(y,x+1,z)
    
    return more,x

def return_range(x,y,z):
    if x == y:
        return z[x:]
    else:
        return z[x:y]
def str_in_it(x,y):
    if type(x) is not list:
        x = [x]
    w = []
    for i in range(0,len(x)):
        if x[i] in str(y):
            w.append(x[i])
        else:
            x.append(False)
    return w
def eat_from_to(w,z):
    ne = ''
    
    ne = z
    z_1 = ''
    z_2 = ''
    z_3 = ''
    for i in range(0,len(w)):
        x,y = w[i]
        res = str_in_it([x,y],z)
        while len(str_in_it([x,y],z)) != 0:
            for i in range(0,len(res)):
                if res[i] != False:
                    if i == 0:
                        ne = z
                        while res[i] not in ne and len(ne) != 0:
                            ne = ne[1:]
                        z_1  = ne[:len(ne)-len(res[i])+1]
                    if i == 1:
                        ne = z.replace(z_1,'')
                        while res[i] not in ne and len(ne) != 0 :
                            ne = ne[1:]
                        z_2  = ne[len(ne):]
            z = z_1 + z_2  
    return z
def for_it(ls,k,det):
    ls_new = []
    for i in range(k,len(ls)):
        if det not in ls[i]:
            ls = f.list_files(ls[i])
            print(ls_new)
        return ls_new
def get_dirs():
    go = 0
    dir = '/home/rugz/Desktop/contract_station'
    ls = dir
    while go != 1:
        ls = for_it(ls,0,'.')
def get_range(x):
    print(x)
    ls = []
    ls_2 = [0]
    for ii in range(0,len(x)):
        n = x[ii]

        ls_2.append(x[ii])
        print(ls)
        if len(ls_2)%2 ==float(0):
            ls.append(ls_2)
            ls_2 = [x[ii]]
            print(ls)
    return ls
def ls_it_all(x,y,z):
    if z == 1:
        return json.loads(str(str(x)[:-1]+','+'"'+str(y)+'":{}}').replace('{,','{').replace("'",'"'))
    else:
        return json.loads(str(str(x)[:-1]+','+'"'+str(y)+'":[]}').replace('{,','{').replace('"','"'))
def prag_solve(c_prag):
    range = []
    #print(c_prag)
    if '>=' in c_prag:
        a = c_prag.split('>=')[1]
        if '<' in a:
            a_b = a.split('<')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        elif '>=' in a:
            a_b = a.split('>=')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        else:
            range.append(float(a.split('0.')[1]))
            range.append(10000)
    elif '>' in c_prag:
        greater = c_prag.split('>')[1].split('0.')[1]
        end = str(int(greater.split('.')[1])+1)
        new = str(int(greater.split('.')[0]))+'.'+end
        range.append(new)
        range.append(10000)
    elif '^' in c_prag:
        up_to = c_prag.split('^')[1].split('0.')[1]
        if up_to.split('.')[1] == '0':
            up_to = int(up_to.split('.')[0])
        range.append(up_to)
        end = int(c_prag.split('^')[1].split('0.')[1].split('.')[0])+1
        range.append(end)
        #print(range)
    else:
        range = [float(c_prag.split('0.')[1]),float(c_prag.split('0.')[1])]
    return range
def in_range(x,y):
    range_1 = prag_solve(x)
    range_2 = prag_solve(y)
    #print(range_2)
    len_it = len(str(range_1[0]))
    len_it_2 = len(str(range_1[1]))
    if len_it_2 > len_it:
        len_it = len_it_2
        if len_it >= 3:
            len_it = len_it - 2
    range_2[0] = float(range_2[0])*float(len_it)
    range_2[1] = float(range_2[1])*float(len_it)
    range_1[0] = float(range_1[0])*float(len_it)
    range_1[1] = float(range_1[1])*float(len_it)
    for i in range(int(range_2[0]),int(range_2[1])):
        #print('iniit',float(i) >= float(range_1[0]),float(i),range_1[0])
        if float(i) >= float(range_1[0]) and float(i) <= float(range_1[1]):
            return True
    return False
            
if '\t' == '        ':


    print('yes!!')

varis = ['function','contract','library','constructor','pragma solidity','import','abstract contract']
heads= ['contract','library','import','pragma solidity','abstract contract']
subs = ['function','constructor','modify']
saves = ['interface','contract','abstract contract','library']
head_sub = ['contract','library','import','pragma solidity','function','constructor','abstract contract','interface']
hea = ['contract','library','pragma solidity','import','interface','abstract contract']
home,slash = f.home_it()
global name_all,parent,all_dirs
docs = home+'/new/'
fi = f.list_files(docs)
for k in range(0,len(fi)):
    name_sol = fi[k]
    name = name_sol.split('.')[0]
    curr_path = f.do_all_dir([home,'flattened',str(name),'main',str(name_sol)])
    f.copy_it('new/'+str(name_sol),curr_path)
    prags = f.line_num('pragma',curr_path)
    lines = f.read_lines(docs+fi[k])
    new = []
    cou_n = -1
    for i in range(0,len(lines)):
        if lines[i] != '\n':
            if cou_n != -1:
                cou_n = -2
            new.append(lines[i])
        if lines[i] == '\n' and cou_n != -2:
            cou_n = cou_n + 1
    cuts = f.line_num('}',docs+fi[k])
    ls_prag = []
    go = 0
    tot = '{}'
    needs = json.loads('{"haves":{},"calls":{},"needs":[]}')
    fin = 0
    cou = 0
    while fin != 1:
        cou_n = -1
        new_new = ''
        for i in range(0,len(lines)):
            if lines[i] != '\n':
                if cou_n != -1:
                    cou_n = -2
                new.append(lines[i])
                new_new = new_new + str(lines[i])
            if lines[i] == '\n' and cou_n != -2:
                cou_n = cou_n + 1
                print(i)
        lines = new
        f.pen(new_new,'new.txt')
        #print(cou)
        if cou > 3:
            fin = 1
        for i in range(0,len(lines)):
            cou_its = 0
            ne_ca = []
            if '// SPDX-License-Identifier:' in lines[i]:
                licens = lines[i]
            use = f.line_num('using ',docs+fi[k])
            for i in range(0,len(use)):
                if 'using ' in lines[use[i]] and ' for ' in lines[use[i]]:
                    ne_ca.append(str(lines[use[i]].split('using ')[1].split(' ')[0]))
                    needs["needs"].append(lines[use[i]].split('using ')[1].split(' ')[0])
                    #needs["needs"].append(lines[i].split('using ')[1].split(' ')[0])
            if lines[i][0] != ' ' and lines[i][0] != '/':
                if 'pragma solidity' in lines[i]:
                    top_prag = lines[i]
                    cur_prag = str(top_prag).split('solidity ')[1].split(';')[0]
                if ' is ' in lines[i]:
                    i_s = lines[i].split('is ')[1].split('{')[0].replace(' ','').split(',')
                    for i in range(0,len(i_s)):
                        ne_ca.append(i_s[i])
 
                if type(ne_ca) is not list:
                    ne_ca = [ne_ca]
                for ii in range(0,len(ne_ca)):
                    ne = ne_ca[ii]
                    if ne not in needs["haves"] and ne not in needs["calls"]:
                        cou = 0
                        needs["calls"] = f.js_it(str(str(needs["calls"])[:-1]+',"'+str(ne)+'":['+str(i)+']}').replace('{,','{').replace('"','"'))
                        print(needs)
                        needs["needs"].append(str(ne))
                        did_it = 0
                        #print(needs)
                        for iii in range(0,len(needs["needs"])):
                            nee = needs["needs"][iii]
                            #print(needs["needs"],nee)
                            if iii == 0:
                                beg,end = lines[:needs["calls"][nee][0]-1],lines[needs["calls"][nee][0]-1:]
                                ne_all = []
                                for iiii in range(0,len(beg)):
                                    ne_all.append(beg[iiii])
                            file = nee+'.sol'
                            
                            pa = f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag])
                            f_l = f.list_files(pa)
                            found = 0
                            fou = ''
                            cou = 0
                            done = []
                            count = 0
                            while found != 1:
                                dir_1 = 'pragmas/'
                                f_ls = f.list_files(dir_1)
                                good = []
                                for q in range(0,len(f_ls)):
                                    #print(nee,in_range(cur_prag,'^'+'0.'+f_ls[q]+'.0'),cur_prag,'^'+'0.'+f_ls[q]+'.0')
                                    if in_range(cur_prag,'^'+'0.'+f_ls[q]+'.0') == True:
                                        d = f.create_path(dir_1,f_ls[q])
                                        good.append(d)
                                good_2 = []
                                for q in range(0,len(good)):
                                    dir_1 = good[q]
                                    f_ls_1 = f.list_files(dir_1)
                                    #print(f_ls_1)
                                    for qq in range(0,len(f_ls_1)):
                                        #print('cur_prag',cur_prag,'comp ',f_ls_1[qq])
                                        if in_range(cur_prag,f_ls_1[qq]) == True:
                                            d = f.create_path(dir_1,f_ls_1[qq])
                                            good_2.append(d)
                                
                                for q in range(0,len(good_2)):
                                    dir_1 = good_2[q]
                                    
                                    f_ls_2 = f.list_files(dir_1)
                                    for qq in range(0,len(f_ls_2)):
                                        f_ls_3 = f.list_files(dir_1)
                                        #print('reeeee',f_ls_3)
                                        for qqq in range(0,len(f_ls_3)):
                                            dir_n = f.create_path(dir_1,f_ls_3[qqq])
                                            f_ls_4 = f.list_files(dir_n)
                                            #print(f_ls_4[0],'sdafadsfasdffdas')
                                            if f_ls_4[0] == 'contract':
                                                f_ls_4[0] = 'abstract contract'
                                                #print(f_ls_4,'asdasdfsdfa',nee)
              
                                            if str(nee)+'.sol' in f_ls_4:
                                                fou = f.read_lines(f.create_path(dir_n,str(nee)+'.sol'))
                                                print(fou)
                                                needs["haves"].append(nee)
                                                print(needs)
                                if fou != '':
                                    ne_all = ''
                                    ne_li_ls = []
                                    delim = needs['calls'][ne][0]
                                    new_li = [lines[:delim-1],fou,lines[delim:]]
                                    for q in range(0,len(new_li)):
                                        for qq in range(0,len(new_li[q])):
                                            ne_li_ls.append(new_li[q][qq])
                                            ne_all = ne_all + str(new_li[q][qq])
                                    f.pen(ne_all,'new.txt')
                                    lines = ne_li_ls
                                    kkk = f.find_it(needs['needs'],nee)
                                    if kkk == 0:
                                        needs['needs'] = needs['needs'][1:]
                                    if kkk == len(needs['needs']):
                                        needs['needs'] = needs['needs'][:-1]
                                    else:
                                        needs['needs'] = needs['needs'][:kkk-1] + needs['needs'][kkk+1:]
                                    #print(needs['needs'])
                                    
                                    count = 0
                                    
                                count = count + 1

                                if len(needs['needs']) == 0:
                                    found = 1
            cou = cou + 1
        ls = ['abstract contract','interface','contract','library']
    lines = f.read_lines('new.txt')
    did_it = 0
    #print(fi[k])
    while did_it != 2:
        have = []
        rang = []
        took = []
        x = len(lines)
        did_it = 0
        i = 0
        while int(i) < len(lines) and did_it == 0:
            prev_last = 0
            if lines[i][0] == '}':
                if len(rang) > 0:
                    rang.append(i)
                    new = [lines[:rang[0]],lines[rang[1]+1:]]
                    new_li = []
                    for q in range(0,len(new)):
                        n = new[q]
                        for qq in range(0,len(n)):
                            new_li.append(n[qq])
                    lines = new_li
                    x = len(lines)
                    rang = []
                    did_it = 1
                prev_last = i+1
            #print(i,len(lines))
            if int(i) < int(len(lines)):
                if lines[i][0] not in [' ','\t','\n']:
                    li = lines[i].split(' ')[0]
                    if str(li) in ls:
                        li_2 = lines[i].split(' ')[1]
                        li_curr = li+' '+li_2
                        if li_curr not in have:
                            have.append(li_curr)
                        else:
                            rang = [prev_last]
                            took.append(li_curr)
            i = i + 1      
        if len(took) == 0:
            new_li_str = ''
            for i in range(0,len(lines)):
                new_li_str = new_li_str + str(lines[i])
            f.pen(licens+new_li_str,'newer/'+fi[k])
            did_it = 2
print(needs['needs'])
                                #for kkk in range(0,len(f_ls_0)):
                                #    print('nopwow',f_ls_0[kkk])
                                #    if in_range(cur_prag,
                                #    if f_ls_0[kkk] not in done:
                                #        for iiii in range(0,len(f_l)):
                                #            done.append(f_l[iiii])
                                #            if file in f.list_files(f.create_path(f.list_files(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0]]))[kkk],f_l[iiii])):
                                #                n = f.read_lines(f.create_path(f.create_path(f.create_path(f.list_files(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0]]))[kkk],f_l[iiii]),f_l[iiii]),file))
                                #                found = 1
                                #                for iiiii in range(0,len(n)):
                                #                    print(n[iiiii])
                                #                    ne_all.append(n[iiiii])
                                #        
                                #    cou = cou + 1
                            
                
            #ne_li = [beg]
            #    new_li = ''
            #    for iiiii in range(0,len(ne_all)):
            #        ne_li.append(f.read_lines(ne_all[iiiii]))
            #    ne_li.append(end)
            #    for iiiiii in range(0,len(ne_li)):
            #        for iiiiiii in range(0,len(ne_li[iiiiii])):
            #            if '// SPDX-License-Identifier:' in ne_li[iiiiii][iiiiiii]:
            #                licens = ne_li[iiiiii][iiiiiii]
            #            else:
            #                new_li = new_li + str(ne_li[iiiiii][iiiiiii])
            #    f.pen(new_li,'new/'+str(name_sol))
            
                        #for iii in range(0,len(f_l)):
                        #    f_l_2 = f.list_files(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,f_l[iii]]))
                        #    for iiii in range(0,len(f_l_2)):
                        #        if str(f_l_2[iiii]).split('.')[0].lower() == ne.lower():
                        #            ne = ''
                        #            print(needs["calls"],['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,f_l[iii],f_l_2[iiii]])
                        #            print(lines[:delim][0])
                        #            print(f.read_lines(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,f_l[iii],f_l_2[iiii]]))[0:5])
                        #            print(f.read_lines(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,f_l[iii],f_l_2[iiii]]))[-5:-1])
                        #            print(lines[delim+1:][0:5])
                        #            fl = [lines[:delim],f.reader(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,f_l[iii],f_l_2[iiii]])),lines[delim+1:]]
                        #            for iiiiii in range(0,len(fl)):
                        #                n = fl[iiiiii]
                        #
                        #                for iiiiiii in range(0,len(n)):
                        #                    ne = ne + n[iiiiiii]
                        #                   
                        #f.pen(ne,'new/'+str(name_sol))
def nogo():                                    
    if cur_prag not in tot:
        tot = ls_it_all(tot,cur_prag,1)
        ls_prag.append(cur_prag)
    res = f.list_var_in_str(str(lines[i]),saves)
    if len(res) != 0 and go == 0:
        go = 1
        hea = res[0]
        if 'abstract contract' in res:
            hea = 'abstract'
        if hea not in needs["haves"]:
            needs["haves"] = f.js_it(str(str(needs["haves"])[:-1]+',"'+str(hea)+'":['+str(i)+']}').replace('{,','{').replace("'",'"'))
        else:
            needs["haves"][hea].append(i)
        tit =lines[i].split(res[0]+' ')[1].split(' ')[0]
        res = []
        new_save = str(f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag,hea,tit+'.sol']))
        new = licens+top_prag
    if '}' == lines[i][0] and go == 1:
        go = 2
if go == 1 or go ==2:
    new = new + str(lines[i])
    if go == 2:
        go = 0
        f.pen(new,new_save)
        new = ''
#for i in range(0,len(prags)):
#    ls_prag.append(str(lines[prags[i]]).split('solidity ')[1].split(';')[0])
#prags_ranges = get_range(prags)
#for i in range(0,len(ls_prag)):
#    lines[prags_ranges[i][0]:prags_ranges[i][1]]
#    for i in range(0,0):
#        print()
#funs = f.line_num('function',fi)
#
#print(prags)

