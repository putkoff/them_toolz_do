import functions as f
import os
import json
def wrap_it(x,y,z):
    global count
    z = str(str(x)[:-1]+f.get_c(len(x))+'"'+str(y)+'":'+str(z)+str(x)[-1]).replace('{,','{').replace(',}','}')

    return f.js_it(z)
def eat_away(x,y,k):
    if is_list(y) == False:
        y = [y]
    n = [0,-1]
    if k == 0:
        k = len(n)
    for i in range(0,k):
        while x[n[i]] in y and len(x) > 0:
            if i == k:
                x = x[:-1]
                
            else:
                x = x[1:]
            if x == '':
                return x
        return x
def find_it(y,x):
    b = len(x)
    i = 0
    while str(x)[0] != y:
        x = x[1:]
        i = i + 1
        return i
    return False
def var_lst(x,ls):
    for i in range(0,len(ls)):
        if x == ls[i]:
            return ls[i]
    return False
def eat(x,ls,d):
    b_ls = [ls,d]
    z = x
    for i in range(0,len(b_ls)):
        if is_list(b_ls[i]) == False:
            b_ls[i] = [b_ls[i]]
    for i in range(0,len(x)):
        if var_lst(x[:i],b_ls[0]) != False:
            return var_lst(x[:i],b_ls[0])
        if x[i] in b_ls[1]:
            return False
    return False
def is_list(x):
    if type(x) is list:
        return True
    return False
def unline(licens,prag,x):
    n = ''
    cou = -1
    li,pr = 0,0
    for i in range(0,len(x)):
        if '// SPDX-License-Identifier:' in x[i]:
            li = 1
        if 'pragma solidity' in x[i]:
            pr = 1
        if x[i] == '\n' and cou < 1:
            if i != 0:
                cou == 0
        else:
            if cou == 0:
                cou = 1
                if li == 0:
                    n = n + licens+'\n'
                    pr = 1
                if pr == 0:
                    n = n + prag
                    pr = 1
            n = n + x[i]
    return n
def rid_of_it(x,y):
    i = int(find_it(y,x['ls']))
    if i == 0:
        x['ls'] = x['ls'][1:]
    if i == len(x['ls']):
        x['ls'] = x['ls'][:-1]
    else:
        x['ls'] = x['ls'][:i-1] + x['ls'][i+1:]
    return x
def prag_solve(c_prag):
    range = []
    #print(c_prag)
    if '>=' in c_prag:
        a = c_prag.split('>=')[1]

        if '<' in a:
            a_b = a.split('<')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        elif '>=' in a:
            a_b = a.split('>=')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        else:
            range.append(float(a.split('0.')[1]))
            range.append(10000)
    elif '>' in c_prag:
        greater = c_prag.split('>')[1].split('0.')[1]
        end = str(int(greater.split('.')[1])+1)
        new = str(int(greater.split('.')[0]))+'.'+end
        range.append(new)
        range.append(10000)
    elif '^' in c_prag:
        up_to = c_prag.split('^')[1].split('0.')[1]
        if up_to.split('.')[1] == '0':
            up_to = int(up_to.split('.')[0])
        range.append(up_to)
        end = int(c_prag.split('^')[1].split('0.')[1].split('.')[0])+1
        range.append(end)
        #print(range)
    else:
        range = [float(c_prag.split('0.')[1]),float(c_prag.split('0.')[1])]
    return range
def in_range(x,y):
    n = [x,y]
    nn = []
    for i in range(0,len(n)):
        if type(n[i]) is not list:
            n[i] = prag_solve(n[i])
        nn.append(n[i])
    range_1 = nn[0]
    range_2 = nn[1]
    #print(range_2)
    len_it = len(str(range_1[0]))
    len_it_2 = len(str(range_1[1]))
    if len_it_2 > len_it:
        len_it = len_it_2
        if len_it >= 3:
            len_it = len_it - 2
    range_2[0] = float(range_2[0])*float(len_it)
    range_2[1] = float(range_2[1])*float(len_it)
    range_1[0] = float(range_1[0])*float(len_it)
    range_1[1] = float(range_1[1])*float(len_it)
    for i in range(int(range_2[0]),int(range_2[1])):
        #print('iniit',float(i) >= float(range_1[0]),float(i),range_1[0])
        if float(i) >= float(range_1[0]) and float(i) <= float(range_1[1]):
            return True
    return False
def is_and_have(x,y):
    killed = []
    for i in range(0,len(x['ls'])):
        n = x['ls']
        if n[i] in y['ls']:
            if in_range(x[n[i]][1],y[n[i]][1]) == True:
                killed.append(n[i])
    for i in range(0,len(killed)):
        x = rid_of_it(x,killed[i])
    return x
def is_check(x,is_ls,k,p):
    if ' is ' in x:
        x = x.split(' is ')[1].replace(' ','').replace('\n','').replace('\t','').split('{')[0].split(',')
        for i in range(0,len(x)):
            is_ls = wrap_it(is_ls,x[i],[k,p])
            if x[i] not in is_ls['ls']:
                is_ls['ls'].append(x[i])
    if 'using ' in x:
        x = x.split('using ')[1].split(' ')[0]
        for i in range(0,len(x)):
            is_ls = wrap_it(is_ls,x[i],[k,p])
            if x[i] not in is_ls['ls']:
                is_ls['ls'].append(x[i])
    return is_ls
global count
count = 0
fi = f.list_files('new/')
for k in range(0,len(fi)):
    file = fi[k]
    subs_ls = ['constructor','using ']
    ls = ['// SPDX-License-Identifier: ','pragma solidity ','contract ','library ','abstract contract ','interface ','}']
    wall_ls = []
    lines = f.read_lines('new/'+file)
    have = json.loads('{}')
    is_ls = json.loads('{"ls":[]}')
    have_ls = json.loads('{"ls":[]}')
    #for i in range(0,len(ls)):
    #    x = wrap_it(x,ls[i],[])
    last_end = 0
    last = ''
    fold = f.do_all_dir(['picked/',str(file)])
    last_prag,curr_prag = '0.8.0','8'
    for i in range(0,len(lines)):
        n = lines[i]
        wall = eat(lines[i],ls,['{','(',';','\t','\n'])
        if wall != False:
            is_ls = is_check(lines[i],is_ls,i,last_prag)
            
            if '// SPDX-License-Identifier: 'in lines[i]:
                licens = lines[i]
            if 'pragma solidity ' in lines[i]:
                last_prag = lines[i].split('pragma solidity ')[1].split(';')[0]
                curr_prag = last_prag.split('0.')[1].split('.')[0]
                prag_range = prag_solve(last_prag)
            
            if '// SPDX-License-Identifier: ' not in lines[i] and 'pragma solidity ' not in lines[i] and bef != 'nogo':
                if wall not in have and wall != '}':
                    if len(have) == 0:
                        have = wrap_it(have,wall,[[],[],[last_end]])
                    else:
                        have = wrap_it(have,wall,[[],[],[]])
                if wall != '}':
                    last = wall
                    last_line = lines[i]
                    have[wall][0].append(lines[i])
                    have[wall][1].append(last_prag)
                    have[wall][-1].append(last_end)
                    name = lines[i].split(wall)[1].split(' ')[0]
                    if name not in have_ls:
                        have_ls = wrap_it(have_ls,name,[i,last_prag])
                        have_ls['ls'].append(name)
                    if name in have_ls and i < have_ls[name][0]:
                        have_ls[name][0] = i
                elif wall == '}':
                    
                    have[last][-1].append(i)
                    print(f.create_path(f.do_all_dir(['prags',str(curr_prag),str(last_prag),str(last)]),name+'.sol'))
                    f.pen(unline(licens,last_prag,lines[last_end+1:i+1]),f.create_path(f.do_all_dir(['prags',str(curr_prag),str(last_prag),str(last)]),name+'.sol'))
                    f.pen(unline(licens,last_prag,lines[last_end+1:i+1]),f.create_path(f.do_all_dir(['newer',file.replace('.sol',''),str(curr_prag),str(last_prag),str(last)]),name+'.sol'))
                    last_end = i
            else:
                bef = 'nogo'
                cou_go = 1
            if wall == '}':
                bef = ''
                cou_go = 0
            
    #subs
    for i in range(0,len(lines)):
        n = lines[i]
        n = eat_away(n,[' ','\t','\n'],1)
        subs = eat(n,subs_ls,[' ','{','(',';','\t','\n'])
        if subs != False:
            is_ls = is_check(lines[i],is_ls,i,last_prag)
            if subs not in have  and subs != '}':
                if len(have) == 0:
                    have = wrap_it(have,wall,[[],[],[last_end]])
                else:
                    have = wrap_it(have,wall,[[],[],[]])
            if subs != '}':
                last = subs
                last_line = lines[i]
                name = lines[i].split(subs)[1].split(' ')[0]
            elif subs == '}':
                last_end = i
                have[last][-1].append(i)
                f.pen(unline(licens,last_prag,lines[last_end+1:i+1]),f.create_path(f.do_all_dir(['prags',str(curr_prag),str(last_prag),str(last)]),name+'.sol'))
                f.pen(unline(licens,last_prag,lines[last_end+1:i+1]),f.create_path(f.do_all_dir(['newer',file.replace('.sol',''),str(curr_prag),str(last_prag),str(last)]),name+'.sol'))
        is_ls = is_and_have(is_ls,have_ls)
    kill_it = []
    while i <  len(is_ls['ls']):
        dir_1 = 'prags/'
        f_ls = f.list_files(dir_1)
        good = []
        for q in range(0,len(f_ls)):
            if in_range(is_ls[is_ls['ls'][i]][1],'^'+'0.'+f_ls[q]+'.0') == True:
                d = f.create_path(dir_1,f_ls[q])
                good.append(d)
        good_2 = []
        for q in range(0,len(good)):
            dir_1 = good[q]
            f_ls_1 = f.list_files(dir_1)
            for qq in range(0,len(f_ls_1)):
                if in_range(is_ls[is_ls['ls'][i]][1],f_ls_1[qq]) == True:
                    d = f.create_path(dir_1,f_ls_1[qq])
                    good_2.append(d)
        for q in range(0,len(good_2)):
            dir_1 = good_2[q]
            f_ls_2 = f.list_files(dir_1)
            for qq in range(0,len(f_ls_2)):
                f_ls_3 = f.list_files(dir_1)
                for qqq in range(0,len(f_ls_3)):
                    dir_n = f.create_path(dir_1,f_ls_3[qqq])
                    f_ls_4 = f.list_files(dir_n)
                    
                    if str(is_ls['ls'][i])+'.sol' in f_ls_4:
                        fou = f.read_lines(f.create_path(dir_n,str(is_ls['ls'][i])+'.sol'))
                        f.pen(unline(licens,last_prag,fou),f.create_path(f.do_all_dir(['newer',file.replace('.sol',''),str(curr_prag),str(last_prag),str(last)]),str(is_ls['ls'][i])+'.sol'))
                        kill_it.append(str(is_ls['ls'][i]))
                        
                        for i in range(0,len(kill_it)):
                            is_ls = rid_of_it(is_ls,kill_it[i])





        
        
        
