import functions as f
import os
import json
import pathlib
def wrap_it(x,y,z):
    z = str(str(x)[:-1]+f.get_c(len(x))+'"'+str(y)+'":'+str(z)+str(x)[-1]).replace('{,','{').replace(',}','}')
    print(z)
    return f.js_it(z)
def eat_away(x,y,k):
    if is_list(y) == False:
        y = [y]
    n = [0,-1]
    if k == 0:
        k = len(n)
    for i in range(0,k):
        while x[n[i]] in y and len(x) > 0:
            if i == k:
                x = x[:-1]
                
            else:
                x = x[1:]
            if x == '':
                return x
        return x
def find_it(y,x):
    b = len(x)
    i = 0
    while str(x)[0] != y:
        x = x[1:]
        i = i + 1
        return i
    return False
def var_lst(x,ls):
    for i in range(0,len(ls)):
        if x == ls[i]:
            return ls[i]
    return False
def eat(x,ls,d):
    b_ls = [ls,d]
    z = x
    for i in range(0,len(b_ls)):
        if is_list(b_ls[i]) == False:
            b_ls[i] = [b_ls[i]]
    for i in range(0,len(x)):
        if var_lst(x[:i],b_ls[0]) != False:
            return var_lst(x[:i],b_ls[0])
        if x[i] in b_ls[1]:
            return False
    return False
def is_list(x):
    if type(x) is list:
        return True
    return False
def unline(licens,prag,x):
    n = ''
    cou = -1
    li,pr = 0,0
    for i in range(0,len(x)):
        if '// SPDX-License-Identifier:' in x[i]:
            li = 1
        if 'pragma solidity' in x[i]:
            pr = 1
        if x[i] == '\n' and cou < 1:
            if i != 0:
                cou == 0
        else:
            if cou == 0:
                cou = 1
                if li == 0:
                    n = n + licens+'\n'
                    pr = 1
                if pr == 0:
                    n = n + prag
                    pr = 1
            n = n + x[i]
    return n
def rid_of_it(x,y):
    i = int(find_it(y,x['ls']))
    if i == 0:
        x['ls'] = x['ls'][1:]
    if i == len(x['ls']):
        x['ls'] = x['ls'][:-1]
    else:
        x['ls'] = x['ls'][:i-1] + x['ls'][i+1:]
    return x
def prag_solve(c_prag):
    range = []
    #print(c_prag)
    if '>=' in c_prag:
        a = c_prag.split('>=')[1]

        if '<' in a:
            a_b = a.split('<')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        elif '>=' in a:
            a_b = a.split('>=')
            a,b = a_b[0].replace(' ',''),a_b[1].replace(' ','')
            a = float(a.split('0.')[1])
            range.append(a)
            b = str(int(str(b.split('0.')[1].split('.')[0])+str(b.split('0.')[1].split('.')[0])) -1)
            b = float(str(b[0])+'.'+str(b[1:]))
            range.append(b)
        else:
            range.append(float(a.split('0.')[1]))
            range.append(10000)
    elif '>' in c_prag:
        greater = c_prag.split('>')[1].split('0.')[1]
        end = str(int(greater.split('.')[1])+1)
        new = str(int(greater.split('.')[0]))+'.'+end
        range.append(new)
        range.append(10000)
    elif '^' in c_prag:
        up_to = c_prag.split('^')[1].split('0.')[1]
        if up_to.split('.')[1] == '0':
            up_to = int(up_to.split('.')[0])
        range.append(up_to)
        end = int(c_prag.split('^')[1].split('0.')[1].split('.')[0])+1
        range.append(end)
        #print(range)
    else:
        range = [float(c_prag.split('0.')[1]),float(c_prag.split('0.')[1])]
    return range
def in_range(x,y):
    n = [x,y]
    nn = []
    for i in range(0,len(n)):
        if type(n[i]) is not list:
            n[i] = prag_solve(n[i])
        nn.append(n[i])
    range_1 = nn[0]
    range_2 = nn[1]
    #print(range_2)
    len_it = len(str(range_1[0]))
    len_it_2 = len(str(range_1[1]))
    if len_it_2 > len_it:
        len_it = len_it_2
        if len_it >= 3:
            len_it = len_it - 2
    range_2[0] = float(range_2[0])*float(len_it)
    range_2[1] = float(range_2[1])*float(len_it)
    range_1[0] = float(range_1[0])*float(len_it)
    range_1[1] = float(range_1[1])*float(len_it)
    for i in range(int(range_2[0]),int(range_2[1])):
        #print('iniit',float(i) >= float(range_1[0]),float(i),range_1[0])
        if float(i) >= float(range_1[0]) and float(i) <= float(range_1[1]):
            return True
    return False
def is_and_have(x,y):
    killed = []
    for i in range(0,len(x['ls'])):
        n = x['ls']
        if n[i] in y['ls']:
            if in_range(x[n[i]][1],y[n[i]][1]) == True:
                killed.append(n[i])
    for i in range(0,len(killed)):
        x = rid_of_it(x,killed[i])
    return x
def is_check(x,is_ls,k,p):
    if ' is ' in x:
        x = x.split(' is ')[1].replace(' ','').replace('\n','').replace('\t','').split('{')[0].split(',')
        for i in range(0,len(x)):
            is_ls = wrap_it(is_ls,x[i],[k,p])
            if x[i] not in is_ls['ls']:
                is_ls['ls'].append(x[i])
    if 'using ' in x:
        x = x.split('using ')[1].split(' ')[0]
        for i in range(0,len(x)):
            is_ls = wrap_it(is_ls,x[i],[k,p])
            if x[i] not in is_ls['ls']:
                is_ls['ls'].append(x[i])
    return is_ls
def get_path():
    return pathlib.Path().resolve()
def for_it(x):
    a,b = [],[]
    for i in range(0,len(x[0])):
        #b.append(f.line_num('}',x[1]+x[0][i]))
        a = f.list_files(x[1]+x[0][i])
    return a,b
books = json.loads('{}')
cont_names = ['IterableMapping', 'NodeManager', 'BigBergNode', 'Disperse', 'NodeManager02', 'NodeStorage', 'NodeController', 'ReferralController', 'LiquidityController']
pr_dir_1 = 'prags/'
cont_dir_1 = 'newer/'
nums = []
p = f.list_files(cont_dir_1)



for i in range(0,len(p)):
    alls = f.create_path(cont_dir_1,p[i])
    alls_ = f.list_files(alls)
    alls = f.create_path(alls,alls_[i])
    
    for ii in range(0,len(alls)):
        alls = f.create_path(cont_dir_1,p[i])
        alls_ = f.list_files(alls)
        alls = f.create_path(alls,alls_[ii])
        for iii in range(0,len(alls[1])):
            alls = f.create_path(cont_dir_1,p[i])
            alls_ = f.list_files(alls)
            alls = f.create_path(alls,alls_[ii])        
            for iiii in range(0,len(alls[1])):
                pragm = f.list_files(prag[iii])
                for iiiii in range(0,len(pragm)):
                    pragmas = f.list_files(pragma[iiiii])
                    books[pr].append(append(str(get_path())))
                    if '.' not in str(pragas):
                         nums.append(f.line_num('}',pragmas[iiii]))          
                    for iiiiii in range(0,len(pragmas)):
                            books[pr].append(append(str(get_path())))

                                    
