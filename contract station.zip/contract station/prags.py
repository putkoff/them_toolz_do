import functions as f
def sep_by_prag(file):
    prev_end = 0
    print(file)
    var = ['pragma solidity','}','contract','library','function','constructor','abstract','interface']
    lines = f.read_lines(file)
    ls = ['abstract contract','interface','contract','library']
    if len(f.line_num('pragma solidity',file)) !=0:
        cur_prag_line = lines[f.line_num('pragma solidity',file)[-1]]
        cur_prag = lines[f.line_num('pragma solidity',file)[-1]].split('pragma solidity ')[1].split(';')[0]
        dir_prag = f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag])

    for i in range(0,len(lines)):
        if 'pragma solidity' in lines[i]:
            cur_prag_line = lines[i]
            cur_prag = lines[i].split('pragma solidity ')[1].split(';')[0]
            dir_prag = f.do_all_dir(['pragmas',cur_prag.split('0.')[1].split('.')[0],cur_prag])
        if '// SPDX-License-Identifier:' in lines[i]:
            lice_line = lines[i]
        if lines[i][0] == '}':
            if len(rang) == 1:
                rang.append(i+1)
                new = lines[rang[0]:rang[1]]
                new_str = ''
                cou = 0
                cou_2 = 0
                for k in range(0,len(new)):
                    new_str = new_str + str(new[k])
                    if 'pragma solidity' in new[k]:
                        cou = 1
                    if '// SPDX-License-Identifier:' in new[k]:
                        cou_2 = 1
                if cou == 0:
                    new_str = str(cur_prag_line)+new_str
                if cou_2 == 1:
                    new_str = str(lice_line)+new_str
            f.pen(new_str,dir_1)
            lones = f.read_lines(dir_1)
            cou_n = -1
            ner_ner = ''
            ner = []
            for qq in range(0,len(lones)):
                if lones[qq] != '\n':
                    if cou_n != -1:
                        cou_n = -2
                    ner.append(lones[qq])
                    ner_ner = ner_ner + str(lones[qq])
                if lones[qq] == '\n' and cou_n != -2:
                    cou_n = cou_n + 1
                    print(qq)
            lones = ner
            f.pen(ner_ner,dir_1)
            rang = []
            prev_end = i
        if lines[i][0] not in [' ','\t','\n']:
            li = lines[i].split(' ')[0]
            print(li)
            if li == 'abstract':
                li = 'abstract contract'
            if str(li) in ls:
                dir_1 = f.do_all_dir([dir_prag,ls[f.find_it(ls,str(li))]])
                if ls[f.find_it(ls,str(li))] == 'abstract contract':
                    print(lines[i])
                    file_sol = lines[i].split('contract ')[1].split(' ')[0]+'.sol'
                    print(file_sol)
                else:
                    file_sol = lines[i].split(' ')[1].split(' ')[0]+'.sol'
                dir_1 = f.do_all_dir([dir_1,file_sol])
                print(dir_1)
                rang = [prev_end+1]
fi = f.list_files('new/')
for i in range(0,len(fi)):
    sep_by_prag('new/'+str(fi[i]))
